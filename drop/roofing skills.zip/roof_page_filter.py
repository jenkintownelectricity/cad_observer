"""
Roof Page Filter
Pre-filters PDF pages to identify roof/waterproofing-related sheets.
Only sends relevant pages to AI vision (cost optimization).

Division 07 - Thermal and Moisture Protection terminology from CSI MasterFormat.
"""

import re
from typing import List, Dict, Tuple
import PyPDF2


# ============================================================================
# DIVISION 07 SPEC SECTIONS - Direct from CSI MasterFormat
# ============================================================================

DIVISION_07_SECTIONS = {
    # 07 10 00 - Dampproofing and Waterproofing
    "07 10 00": "Dampproofing and Waterproofing",
    "07 11 00": "Dampproofing",
    "07 12 00": "Built-up Bituminous Waterproofing",
    "07 13 00": "Sheet Waterproofing",
    "07 14 00": "Fluid-Applied Waterproofing",
    "07 16 00": "Cementitious and Reactive Waterproofing",
    "07 17 00": "Bentonite Waterproofing",
    "07 18 00": "Traffic Coatings",
    "07 19 00": "Water Repellents",
    
    # 07 20 00 - Thermal Protection
    "07 21 00": "Thermal Insulation",
    "07 22 00": "Roof and Deck Insulation",
    "07 24 00": "Exterior Insulation and Finish Systems (EIFS)",
    "07 25 00": "Weather Barriers",
    "07 26 00": "Vapor Retarders",
    "07 27 00": "Air Barriers",
    
    # 07 30 00 - Steep Slope Roofing
    "07 31 00": "Shingles and Shakes",
    "07 32 00": "Roof Tiles",
    "07 33 00": "Natural Roof Coverings",
    "07 41 00": "Roof Panels",
    "07 42 00": "Wall Panels",
    
    # 07 50 00 - Membrane Roofing
    "07 50 00": "Membrane Roofing",
    "07 51 00": "Built-Up Bituminous Roofing",
    "07 52 00": "Modified Bituminous Membrane Roofing",
    "07 53 00": "Elastomeric Membrane Roofing",
    "07 54 00": "Thermoplastic Membrane Roofing",
    "07 55 00": "Protected Membrane Roofing",
    "07 56 00": "Fluid-Applied Roofing",
    "07 57 00": "Coated Foamed Roofing",
    "07 58 00": "Roll Roofing",
    
    # 07 60 00 - Flashing and Sheet Metal
    "07 60 00": "Flashing and Sheet Metal",
    "07 61 00": "Sheet Metal Roofing",
    "07 62 00": "Sheet Metal Flashing and Trim",
    "07 63 00": "Sheet Metal Roofing Specialties",
    "07 65 00": "Flexible Flashing",
    
    # 07 70 00 - Roof and Wall Specialties
    "07 71 00": "Roof Specialties",
    "07 72 00": "Roof Accessories",
    "07 76 00": "Roof Pavers",
    "07 77 00": "Wall Specialties",
    
    # 07 80 00 - Fire and Smoke Protection
    "07 81 00": "Applied Fireproofing",
    "07 84 00": "Firestopping",
    
    # 07 90 00 - Joint Protection
    "07 91 00": "Preformed Joint Seals",
    "07 92 00": "Joint Sealants",
    "07 95 00": "Expansion Control",
}


# ============================================================================
# KEYWORD SCORING - Division 07 Terminology
# ============================================================================

# Sheet title patterns (highest weight - these ARE roof sheets)
SHEET_TITLE_PATTERNS = [
    r'\bROOF\s+PLAN\b',
    r'\bROOFING\s+PLAN\b',
    r'\bROOF\s+DETAIL[S]?\b',
    r'\bROOFING\s+DETAIL[S]?\b',
    r'\bROOF\s+DRAIN\s+SCHEDULE\b',
    r'\bROOF\s+FRAMING\b',
    r'\bROOF\s+ASSEMBLY\b',
    r'\bROOFING\s+SCHEDULE\b',
    r'\bWATERPROOFING\s+PLAN\b',
    r'\bWATERPROOFING\s+DETAIL[S]?\b',
    r'\bPLAZA\s+DECK\b',
    r'\bPODIUM\s+DECK\b',
    r'\bVEGETATED\s+ROOF\b',
    r'\bGREEN\s+ROOF\b',
]

# Membrane & roofing systems (high weight)
MEMBRANE_KEYWORDS = [
    # Single-ply membranes
    r'\bTPO\b',
    r'\bEPDM\b',
    r'\bPVC\s+MEMBRANE\b',
    r'\bKEE\b',  # KEE membrane
    r'\bSINGLE[\s-]?PLY\b',
    
    # Modified bitumen
    r'\bMOD[\s-]?BIT\b',
    r'\bMODIFIED\s+BITUMEN\b',
    r'\bSBS\b',
    r'\bAPP\b',
    r'\bTORCH[\s-]?APPLIED\b',
    r'\bCOLD[\s-]?APPLIED\b',
    r'\bSELF[\s-]?ADHERED\b',
    
    # Built-up roofing
    r'\bBUR\b',
    r'\bBUILT[\s-]?UP\s+ROOF',
    r'\bHOT[\s-]?MOPPED\b',
    r'\bCOAL\s+TAR\b',
    
    # Fluid-applied
    r'\bFLUID[\s-]?APPLIED\b',
    r'\bSPRAY[\s-]?APPLIED\b',
    r'\bPMMA\b',
    r'\bSILICONE\s+COATING\b',
    r'\bURETHANE\s+COATING\b',
    
    # Waterproofing membranes
    r'\bBENTONITE\b',
    r'\bHDPE\b',
    r'\bRUBBERIZED\s+ASPHALT\b',
    r'\bBITUTHENE\b',
    r'\bPREPRUFE\b',
    r'\bMIRAPLY\b',
]

# Flashing & sheet metal (high weight)
FLASHING_KEYWORDS = [
    r'\bFLASHING\b',
    r'\bCOUNTER[\s-]?FLASHING\b',
    r'\bBASE\s+FLASHING\b',
    r'\bCAP\s+FLASHING\b',
    r'\bSTEP\s+FLASHING\b',
    r'\bTHROUGH[\s-]?WALL\s+FLASHING\b',
    r'\bREGLET\b',
    r'\bDRIP\s+EDGE\b',
    r'\bGRAVEL\s+STOP\b',
    r'\bFASCIA\b',
    r'\bCOPING\b',
    r'\bPARAPET\s+CAP\b',
    r'\bEDGE\s+METAL\b',
    r'\bTERMINATION\s+BAR\b',
    r'\bCLEAT\b',
]

# Drainage (high weight)
DRAINAGE_KEYWORDS = [
    r'\bROOF\s+DRAIN\b',
    r'\bDRAIN\s+BOWL\b',
    r'\bDRAIN\s+SUMP\b',
    r'\bOVERFLOW\s+DRAIN\b',
    r'\bSCUPPER\b',
    r'\bCONDUCTOR\s+HEAD\b',
    r'\bLEADER\b',
    r'\bDOWNSPOUT\b',
    r'\bGUTTER\b',
    r'\bCRICKET\b',
    r'\bSADDLE\b',
    r'\bTAPERED\s+INSULATION\b',
]

# Penetrations & curbs (medium weight)
PENETRATION_KEYWORDS = [
    r'\bROOF\s+PENETRATION\b',
    r'\bPIPE\s+BOOT\b',
    r'\bPIPE\s+SUPPORT\b',
    r'\bPITCH\s+PAN\b',
    r'\bPITCH\s+POCKET\b',
    r'\bMECHANICAL\s+CURB\b',
    r'\bEQUIPMENT\s+CURB\b',
    r'\bRTU\s+CURB\b',
    r'\bSKYLIGHT\s+CURB\b',
    r'\bHATCH\b',
    r'\bRoof\s+HATCH\b',
    r'\bSMOKE\s+VENT\b',
    r'\bVENT\s+STACK\b',
    r'\bPLUMBING\s+VENT\b',
]

# Insulation (medium weight)
INSULATION_KEYWORDS = [
    r'\bROOF\s+INSULATION\b',
    r'\bRIGID\s+INSULATION\b',
    r'\bPOLYISO\b',
    r'\bISO\s+BOARD\b',
    r'\bXPS\b',
    r'\bEPS\b',
    r'\bCOVER\s+BOARD\b',
    r'\bGYPSUM\s+BOARD\b',
    r'\bDENS[\s-]?DECK\b',
    r'\bSECUROCK\b',
    r'\bR[\s-]?VALUE\b',
    r'\bTHERMAL\s+BARRIER\b',
]

# Air/vapor barriers (medium weight)
BARRIER_KEYWORDS = [
    r'\bAIR\s+BARRIER\b',
    r'\bVAPOR\s+BARRIER\b',
    r'\bVAPOR\s+RETARDER\b',
    r'\bSELF[\s-]?ADHERED\s+MEMBRANE\b',
    r'\bWEATHER\s+BARRIER\b',
    r'\bBUILDING\s+WRAP\b',
]

# Roof specialties (medium weight)
SPECIALTY_KEYWORDS = [
    r'\bEXPANSION\s+JOINT\b',
    r'\bAREA\s+DIVIDER\b',
    r'\bWALKWAY\s+PAD\b',
    r'\bROOF\s+PAVER\b',
    r'\bPEDESTAL\b',
    r'\bSNOW\s+GUARD\b',
    r'\bLIGHTNING\s+PROTECTION\b',
    r'\bFALL\s+PROTECTION\b',
    r'\bANCHOR\s+POINT\b',
    r'\bLADDER\b',
    r'\bSHIP[\s-]?LADDER\b',
]

# Structural/substrate (lower weight - context dependent)
SUBSTRATE_KEYWORDS = [
    r'\bMETAL\s+DECK\b',
    r'\bSTEEL\s+DECK\b',
    r'\bCONCRETE\s+DECK\b',
    r'\bLIGHTWEIGHT\s+CONCRETE\b',
    r'\bGYPCRETE\b',
    r'\bPLYWOOD\s+DECK\b',
    r'\bOSB\b',
    r'\bSTRUCTURAL\s+CONCRETE\b',
]

# Sealants & adhesives (lower weight)
SEALANT_KEYWORDS = [
    r'\bSEALANT\b',
    r'\bJOINT\s+SEALANT\b',
    r'\bSILICONE\s+SEALANT\b',
    r'\bURETHANE\s+SEALANT\b',
    r'\bBACKER\s+ROD\b',
    r'\bBONDING\s+ADHESIVE\b',
    r'\bPRIMER\b',
]

# Manufacturer names (context - confirms it's spec/product related)
MANUFACTURER_KEYWORDS = [
    r'\bCARLISLE\b',
    r'\bFIRESTONE\b',
    r'\bGAF\b',
    r'\bJOHNS\s+MANVILLE\b',
    r'\bSOPREMA\b',
    r'\bSIKA\b',
    r'\bTREMCO\b',
    r'\bHENRY\b',
    r'\bCERTAINTEED\b',
    r'\bOWENS\s+CORNING\b',
    r'\bPOLYGLASS\b',
    r'\bW\.R\.\s+MEADOWS\b',
    r'\bCARLISLE\s+CCW\b',
    r'\bGRACE\b',
]


# ============================================================================
# SCORING WEIGHTS
# ============================================================================

SCORE_WEIGHTS = {
    'sheet_title': 50,      # Sheet is definitely about roofing
    'membrane': 20,         # Strong indicator
    'flashing': 20,         # Strong indicator
    'drainage': 15,         # Strong indicator
    'penetration': 10,      # Medium indicator
    'insulation': 10,       # Medium indicator
    'barrier': 10,          # Medium indicator
    'specialty': 8,         # Medium indicator
    'substrate': 5,         # Context dependent
    'sealant': 5,           # Context dependent
    'manufacturer': 3,      # Weak alone, confirms context
    'spec_section': 15,     # Division 07 section number found
}

# Threshold to consider a page "roof-related"
ROOF_PAGE_THRESHOLD = 25


# ============================================================================
# FILTERING FUNCTIONS
# ============================================================================

def extract_text_from_page(pdf_reader: PyPDF2.PdfReader, page_num: int) -> str:
    """Extract text from a single PDF page."""
    try:
        page = pdf_reader.pages[page_num]
        text = page.extract_text() or ""
        return text.upper()  # Normalize to uppercase for matching
    except Exception as e:
        print(f"Error extracting page {page_num}: {e}")
        return ""


def find_spec_sections(text: str) -> List[str]:
    """Find Division 07 spec section numbers in text."""
    found = []
    # Match patterns like "07 52 00" or "075200" or "07-52-00"
    pattern = r'07[\s\-]?\d{2}[\s\-]?\d{2}'
    matches = re.findall(pattern, text)
    for match in matches:
        # Normalize to "07 XX 00" format
        clean = re.sub(r'[\s\-]', '', match)
        if len(clean) == 6:
            normalized = f"{clean[:2]} {clean[2:4]} {clean[4:]}"
            if normalized in DIVISION_07_SECTIONS:
                found.append(normalized)
    return list(set(found))


def score_keyword_category(text: str, patterns: List[str]) -> int:
    """Count matches for a category of keywords."""
    count = 0
    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        count += len(matches)
    return count


def calculate_page_score(text: str) -> Dict:
    """Calculate roof-relevance score for a page."""
    scores = {
        'sheet_title': score_keyword_category(text, SHEET_TITLE_PATTERNS),
        'membrane': score_keyword_category(text, MEMBRANE_KEYWORDS),
        'flashing': score_keyword_category(text, FLASHING_KEYWORDS),
        'drainage': score_keyword_category(text, DRAINAGE_KEYWORDS),
        'penetration': score_keyword_category(text, PENETRATION_KEYWORDS),
        'insulation': score_keyword_category(text, INSULATION_KEYWORDS),
        'barrier': score_keyword_category(text, BARRIER_KEYWORDS),
        'specialty': score_keyword_category(text, SPECIALTY_KEYWORDS),
        'substrate': score_keyword_category(text, SUBSTRATE_KEYWORDS),
        'sealant': score_keyword_category(text, SEALANT_KEYWORDS),
        'manufacturer': score_keyword_category(text, MANUFACTURER_KEYWORDS),
    }
    
    # Check for spec sections
    spec_sections = find_spec_sections(text)
    scores['spec_section'] = len(spec_sections)
    
    # Calculate weighted total
    total = 0
    for category, count in scores.items():
        total += count * SCORE_WEIGHTS.get(category, 1)
    
    return {
        'category_hits': scores,
        'spec_sections_found': spec_sections,
        'total_score': total,
        'is_roof_page': total >= ROOF_PAGE_THRESHOLD,
    }


def filter_roof_pages(pdf_path: str, threshold: int = None) -> Dict:
    """
    Filter a PDF to identify roof/waterproofing-related pages.
    
    Returns:
        Dict with:
            - total_pages: Total pages in PDF
            - roof_pages: List of (page_num, score_details) for roof pages
            - roof_page_numbers: Just the page numbers (0-indexed)
            - summary: Quick stats
    """
    if threshold is None:
        threshold = ROOF_PAGE_THRESHOLD
    
    results = {
        'total_pages': 0,
        'roof_pages': [],
        'roof_page_numbers': [],
        'all_page_scores': [],
        'summary': {},
    }
    
    try:
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            results['total_pages'] = len(reader.pages)
            
            for page_num in range(len(reader.pages)):
                text = extract_text_from_page(reader, page_num)
                score = calculate_page_score(text)
                score['page_num'] = page_num
                
                results['all_page_scores'].append(score)
                
                if score['total_score'] >= threshold:
                    results['roof_pages'].append((page_num, score))
                    results['roof_page_numbers'].append(page_num)
    
    except Exception as e:
        results['error'] = str(e)
        return results
    
    # Generate summary
    results['summary'] = {
        'total_pages': results['total_pages'],
        'roof_pages_found': len(results['roof_pages']),
        'percentage_roof': round(len(results['roof_pages']) / max(results['total_pages'], 1) * 100, 1),
        'threshold_used': threshold,
    }
    
    return results


def get_roof_page_text(pdf_path: str, page_numbers: List[int] = None) -> Dict[int, str]:
    """
    Extract text from specific pages (or all roof pages if not specified).
    
    Use this to get the actual content for AI vision processing.
    """
    if page_numbers is None:
        # Auto-detect roof pages
        filter_results = filter_roof_pages(pdf_path)
        page_numbers = filter_results['roof_page_numbers']
    
    page_text = {}
    
    try:
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page_num in page_numbers:
                if 0 <= page_num < len(reader.pages):
                    page_text[page_num] = extract_text_from_page(reader, page_num)
    except Exception as e:
        page_text['error'] = str(e)
    
    return page_text


# ============================================================================
# CLI INTERFACE
# ============================================================================

if __name__ == "__main__":
    import sys
    import json
    
    if len(sys.argv) < 2:
        print("Usage: python roof_page_filter.py <pdf_path> [threshold]")
        print("\nFilters PDF pages to find roof/waterproofing-related sheets.")
        print("Default threshold: 25")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    threshold = int(sys.argv[2]) if len(sys.argv) > 2 else None
    
    print(f"Analyzing: {pdf_path}")
    print("-" * 60)
    
    results = filter_roof_pages(pdf_path, threshold)
    
    if 'error' in results:
        print(f"Error: {results['error']}")
        sys.exit(1)
    
    print(f"Total pages: {results['summary']['total_pages']}")
    print(f"Roof pages found: {results['summary']['roof_pages_found']}")
    print(f"Percentage: {results['summary']['percentage_roof']}%")
    print("-" * 60)
    
    if results['roof_pages']:
        print("\nRoof-related pages:")
        for page_num, score in results['roof_pages']:
            print(f"\n  Page {page_num + 1} (score: {score['total_score']})")
            
            # Show spec sections found
            if score['spec_sections_found']:
                sections = ', '.join(score['spec_sections_found'])
                print(f"    Spec sections: {sections}")
            
            # Show top categories
            top_cats = sorted(
                score['category_hits'].items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
            cats_str = ', '.join(f"{k}:{v}" for k, v in top_cats if v > 0)
            if cats_str:
                print(f"    Top hits: {cats_str}")
    else:
        print("\nNo roof-related pages found.")
    
    # Output JSON for piping to other tools
    print("\n" + "=" * 60)
    print("JSON output:")
    print(json.dumps({
        'roof_page_numbers': [p + 1 for p in results['roof_page_numbers']],  # 1-indexed for humans
        'summary': results['summary'],
    }, indent=2))
