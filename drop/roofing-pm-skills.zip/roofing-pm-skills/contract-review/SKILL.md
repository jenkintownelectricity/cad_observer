# Contract Review Skill

## Purpose
Review subcontract terms, identify risks, flag problematic clauses, and understand contract obligations.

## When to Use
- User is reviewing a subcontract before signing
- User asks about contract terms
- User needs to understand payment provisions
- User asks about insurance requirements
- User has questions about specific clauses

## Contract Review Checklist

### Basic Information
- [ ] Parties correctly identified
- [ ] Project name and address correct
- [ ] Contract amount correct
- [ ] Scope of work matches bid
- [ ] Start and completion dates reasonable

### Scope of Work
- [ ] Scope clearly defined
- [ ] Matches your proposal
- [ ] No scope creep from bid
- [ ] Exclusions acknowledged
- [ ] Unit prices for changes

### Payment Terms
- [ ] Payment schedule clear
- [ ] Retention percentage
- [ ] Pay-when-paid vs pay-if-paid
- [ ] Payment timing (net 30, etc.)
- [ ] Change order process
- [ ] Final payment conditions

### Insurance Requirements
- [ ] Limits achievable
- [ ] Additional insured requirements
- [ ] Waiver of subrogation
- [ ] Professional liability needed?

### Schedule
- [ ] Duration reasonable
- [ ] Liquidated damages
- [ ] Delay provisions
- [ ] Notice requirements for delays

### Warranty
- [ ] Warranty duration
- [ ] Warranty scope
- [ ] Maintenance obligations
- [ ] Call-back provisions

### Indemnification
- [ ] Mutual or one-sided
- [ ] Scope of indemnity
- [ ] Insurance coverage alignment

### Termination
- [ ] Termination for convenience
- [ ] Termination for cause
- [ ] Notice requirements
- [ ] Payment upon termination

### Disputes
- [ ] Dispute resolution process
- [ ] Mediation/arbitration
- [ ] Venue/jurisdiction
- [ ] Attorney fees

## Red Flag Clauses

### Payment
⚠️ **Pay-if-paid clause**
"Contractor shall pay Subcontractor only if and when Contractor receives payment from Owner."
- RISK: You may never get paid if owner doesn't pay
- NEGOTIATE: Change to "pay-when-paid" or fixed timeline

⚠️ **Excessive retention**
- Standard: 5-10%
- Red flag: >10% or no release date specified

⚠️ **No payment for stored materials**
- Standard: Payment for delivered materials
- Red flag: Payment only after installation

### Indemnification
⚠️ **Broad form indemnity**
"Subcontractor shall indemnify Contractor for ALL claims arising from the work, including Contractor's own negligence."
- RISK: You're liable for their mistakes
- NEGOTIATE: Limit to your own negligence

⚠️ **Duty to defend**
"Subcontractor shall defend..."
- RISK: You pay legal fees immediately
- CHECK: Does insurance cover defense?

### Schedule
⚠️ **Liquidated damages flow-down**
"Subcontractor shall be liable for liquidated damages assessed against Contractor."
- RISK: Unlimited liability
- NEGOTIATE: Cap at contract value or % thereof

⚠️ **No-damage-for-delay**
"Subcontractor's sole remedy for delay shall be time extension."
- RISK: Can't recover extended costs
- CHECK: Are there exceptions?

### Warranty
⚠️ **Extended warranty beyond manufacturer**
"Subcontractor warrants work for 10 years."
- RISK: Extends beyond manufacturer warranty
- NEGOTIATE: Match manufacturer warranty

⚠️ **Maintenance responsibility**
"Subcontractor shall perform maintenance for warranty period."
- RISK: Free service calls
- NEGOTIATE: Maintenance by owner or separate contract

### Insurance
⚠️ **Primary and non-contributory**
"Subcontractor's insurance shall be primary and non-contributory."
- RISK: Your insurance pays first always
- CHECK: Policy allows this endorsement

⚠️ **Excessive limits**
"$5M per occurrence, $10M aggregate"
- RISK: May need umbrella policy
- COST: Get insurance quote before signing

## Payment Provision Analysis

### Pay-When-Paid (Generally Enforceable)
"Payment due within 10 days of Contractor's receipt of payment from Owner."
- You get paid, just timing depends on owner payment
- Usually enforceable

### Pay-If-Paid (Varies by State)
"Payment contingent upon and subject to Contractor's receipt of payment from Owner."
- Creates condition precedent
- Unenforceable in some states
- RISK: No owner payment = no subcontractor payment

### State Laws
Some states prohibit pay-if-paid:
- California
- New York  
- Illinois
- Others (check local law)

## Insurance Requirements Decoder

### Standard Requirements
| Coverage | Typical Limit |
|----------|---------------|
| General Liability | $1M/$2M |
| Auto Liability | $1M |
| Workers Comp | Statutory |
| Umbrella | $5M-$10M |

### Additional Insured
- Standard requirement
- Adds GC/Owner to your policy
- Must request endorsement from insurer

### Waiver of Subrogation
- Prevents insurer from suing other parties
- May require endorsement
- Additional premium may apply

### Professional Liability / E&O
- Usually for design professionals
- May be required if you provide design services
- Expensive coverage

## Change Order Provisions

### Good Language
"Changes shall be agreed upon in writing before work proceeds. Subcontractor entitled to reasonable overhead and profit on changes."

### Red Flag Language
"Subcontractor shall proceed with changes as directed. Pricing to be agreed upon subsequently."
- RISK: Work without agreed price
- NEGOTIATE: Written authorization before work

### Check For:
- [ ] Written authorization required
- [ ] Pricing deadline
- [ ] Markup percentages allowed
- [ ] Dispute resolution for pricing

## Delay and Time Extension

### Good Provisions
- Written notice requirement (reasonable, e.g., 7 days)
- Time extension for weather, owner delays
- Cost recovery for owner-caused delays

### Bad Provisions
- Very short notice periods (24-48 hours)
- No cost recovery (time only)
- Broad no-damage-for-delay clause
- Your delays = their damages

## Contract Negotiation Tips

### What to Negotiate
1. Pay-if-paid → pay-when-paid
2. Broad indemnity → limited to your negligence
3. Excessive retention → reduce or add release trigger
4. Unlimited LD exposure → cap at contract value
5. Long warranty → match manufacturer
6. Unreasonable insurance → achievable limits

### How to Negotiate
1. Mark up contract with proposed changes
2. Provide written explanation for each change
3. Offer alternatives, not just rejections
4. Prioritize deal-breakers vs. nice-to-haves
5. Get changes in writing before signing

### Walk-Away Items
- Unlimited personal liability
- Pay-if-paid in pay-if-paid state
- Uninsurable indemnity requirements
- Unrealistic schedule with LD
- Scope doesn't match bid

## Contract Summary Template

```
CONTRACT REVIEW SUMMARY

Project: _________
GC: _________
Contract Amount: $_________
Review Date: _________
Reviewed by: _________

OVERVIEW:
Contract type: [ ] Lump sum [ ] Unit price [ ] T&M
Duration: _____ days
Start date: _________
Completion date: _________

PAYMENT:
[ ] Pay-when-paid (_____ days after GC receipt)
[ ] Pay-if-paid (⚠️ RISK)
[ ] Net _____ days
Retention: _____% 
Retention release: _________

INSURANCE:
GL: $_____ / $_____
Auto: $_____
WC: Statutory
Umbrella: $_____
[ ] Additional insured required
[ ] Waiver of subrogation required

RED FLAGS:
1. _________
2. _________
3. _________

RECOMMENDED CHANGES:
1. _________
2. _________
3. _________

RECOMMENDATION:
[ ] Sign as-is
[ ] Sign with noted changes
[ ] Do not sign - negotiate
[ ] Walk away

Notes: _________
```

## Questions to Ask User

1. "What are you most concerned about in this contract?"
2. "What's the contract amount and project size?"
3. "Do you have the required insurance limits?"
4. "What payment terms did you include in your bid?"
5. "What's the project schedule and is it realistic?"
6. "Are there any unusual requirements in the scope?"
