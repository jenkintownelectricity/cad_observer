# Submittals Skill

## Purpose
Prepare and manage roofing submittals including product data, shop drawings, samples, and certifications.

## When to Use
- User needs to prepare a submittal package
- User asks what's required for a submittal
- User needs to track submittal status
- User needs to respond to submittal rejections

## Submittal Types

### 1. Product Data
- Manufacturer data sheets
- Technical specifications
- MSDS/SDS sheets
- Test reports (ASTM compliance)
- FM/UL approvals

### 2. Shop Drawings
- Roof plan showing system layout
- Detail drawings (flashing, edges, penetrations)
- Drain locations
- Seam layout
- Fastener patterns

### 3. Samples
- Membrane samples (color/texture)
- Metal finish samples
- Walkway pad samples

### 4. Certificates
- Manufacturer authorization letter
- Installer certification/training records
- Insurance certificates

### 5. Warranty Documentation
- Draft warranty
- Maintenance requirements
- Registration forms

## Submittal Package Contents

### Cover Sheet
```
SUBMITTAL TRANSMITTAL

Project: ____________________
Submittal #: ________________
Date: ______________________
Spec Section: _______________

From: [Contractor]
To: [GC/Architect]

Description of Submittal:
_________________________________

Action Requested:
[ ] Approval
[ ] Approval as Noted
[ ] Review and Comment
[ ] Information Only

Contractor Certification:
"We have reviewed this submittal and certify it 
complies with contract requirements."

Signature: __________________
Date: ______________________
```

### Typical Package Organization

```
ROOFING SUBMITTAL PACKAGE
Section 07 54 00 - Thermoplastic Membrane Roofing

Tab 1 - TRANSMITTAL & INDEX
  1.1 Transmittal form
  1.2 Submittal index/checklist

Tab 2 - MEMBRANE SYSTEM
  2.1 Manufacturer overview
  2.2 System description
  2.3 TPO membrane data sheet
  2.4 ASTM test reports
  2.5 FM approval documentation
  2.6 Color chart

Tab 3 - INSULATION
  3.1 Polyiso insulation data sheet
  3.2 Cover board data sheet
  3.3 R-value calculations
  3.4 FM approval

Tab 4 - ACCESSORIES
  4.1 Fasteners data sheet
  4.2 Adhesive data sheet
  4.3 Sealant data sheet
  4.4 Walkway pad data sheet
  4.5 Drain data sheets

Tab 5 - SHEET METAL
  5.1 Edge metal profiles
  5.2 Metal finish samples
  5.3 Gauge verification

Tab 6 - SHOP DRAWINGS
  6.1 Roof plan
  6.2 Flashing details
  6.3 Drain details
  6.4 Edge details
  6.5 Penetration details

Tab 7 - CERTIFICATIONS
  7.1 Manufacturer authorization
  7.2 Installer certifications
  7.3 Insurance certificate
  7.4 Safety certifications

Tab 8 - WARRANTY
  8.1 Draft warranty document
  8.2 Maintenance requirements
  8.3 Registration requirements
```

## Shop Drawing Requirements

### Roof Plan Should Show
- Building outline and dimensions
- Roof area boundaries
- Drain locations with sizes
- Penetration locations
- Equipment curb locations
- Seam layout
- Edge conditions
- Match lines (if multiple sheets)
- North arrow and scale
- Notes and legend

### Detail Drawings Should Include
- Base flashing at walls
- Base flashing at curbs
- Edge metal profiles
- Coping details
- Expansion joint details
- Drain details
- Pipe penetration details
- Scupper details

### Drawing Standards
- Scale: 3/4" = 1'-0" or larger for details
- Scale: 1/8" = 1'-0" or 1/16" = 1'-0" for plans
- Include dimensions
- Label all materials
- Reference spec sections
- Show manufacturer and product names
- Include revision block

## Submittal Review Responses

### "Approved"
- Proceed with work
- Keep approved copy on site

### "Approved as Noted"
- Proceed with noted modifications
- Incorporate all markups
- May need to resubmit corrected version

### "Revise and Resubmit"
- Do NOT proceed
- Address all comments
- Resubmit for approval

### "Rejected"
- Do NOT proceed
- Major issues exist
- May need different products
- Discuss with architect

## Common Rejection Reasons

### Product Data Issues
- Missing ASTM test reports
- Product doesn't meet spec requirements
- Missing FM/UL approval documentation
- Outdated data sheets

### Shop Drawing Issues
- Missing details
- Incorrect scale
- Missing dimensions
- Doesn't match spec requirements
- Missing seam layout
- Incorrect materials shown

### Certification Issues
- Installer not certified by manufacturer
- Missing training documentation
- Insurance certificate expired
- Missing manufacturer authorization

## Resubmittal Tips

1. **Address ALL comments** - Don't leave any unresolved
2. **Cloud changes** - Mark what was revised
3. **Reference original** - Note "Rev 1 per comments dated..."
4. **Include response letter** - Explain how each comment was addressed
5. **Keep copies** - Document everything

## Response to Rejection Letter Template

```
[DATE]

[ARCHITECT]
[ADDRESS]

RE: [PROJECT NAME]
    Submittal Response - Section 07 54 00
    Original Submittal: [DATE]
    Your Response: [DATE]

The following addresses your review comments:

COMMENT 1: [Quote their comment]
RESPONSE: [Your response/action taken]
SEE: Tab X, Page X

COMMENT 2: [Quote their comment]
RESPONSE: [Your response/action taken]
SEE: Tab X, Page X

[Continue for all comments]

All other items remain unchanged from original submittal.

Please contact us with any questions.

[SIGNATURE]
```

## Submittal Tracking Log

```
| Sub # | Spec | Description | Sent | Returned | Status | Notes |
|-------|------|-------------|------|----------|--------|-------|
| 001   | 07 54| TPO System  | 1/15 | 1/22     | App'd  |       |
| 002   | 07 62| Edge Metal  | 1/15 | 1/25     | R&R    | Detail|
| 002-R1| 07 62| Edge Metal  | 1/28 | 2/5      | App'd  |       |
| 003   | 07 72| Drains      | 1/18 | Pending  |        |       |
```

## Timeline Guidelines

- Submit within 2-3 weeks of contract
- Allow 2 weeks for review
- Allow 1 week for resubmittal review
- Order materials after approval
- Don't delay fabrication items

## Questions to Ask User

1. "What spec section(s) are we submitting for?"
2. "Do you have the contract submittal schedule?"
3. "Are there any previous submittals I should reference?"
4. "What format is required?" (Paper/electronic)
5. "How many copies are required?"
6. "Is there a specific submittal form to use?"
