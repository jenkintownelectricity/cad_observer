# RFI Writer Skill

## Purpose
Draft clear, professional Requests for Information (RFIs) and track responses.

## When to Use
- User finds a conflict in documents
- User needs clarification on scope
- User discovers unforeseen conditions
- User needs direction from architect/engineer

## RFI Best Practices

### When to Write an RFI
- Conflicting information between drawings and specs
- Missing information needed to proceed
- Unforeseen site conditions
- Scope clarification needed
- Substitution requests
- Ambiguous details or dimensions

### When NOT to Write an RFI
- Information is clearly stated (you just missed it)
- Question can be resolved at site meeting
- Means and methods decisions (your expertise)
- Pricing questions (use PCO instead)

## RFI Structure

### Required Elements
1. **RFI Number** - Sequential tracking number
2. **Date** - Date submitted
3. **Project Name** - Full project name
4. **Subject** - Brief, specific description
5. **Reference** - Drawing/spec/location reference
6. **Question** - Clear, specific question
7. **Suggested Solution** - Your proposed resolution
8. **Impact Statement** - Schedule/cost impact if delayed
9. **Attachments** - Supporting documents, sketches

### RFI Form Template

```
REQUEST FOR INFORMATION

RFI #: [NUMBER]                     Date: [DATE]
Project: [PROJECT NAME]             
From: [YOUR COMPANY]                To: [GC/ARCHITECT]

SUBJECT: [Brief descriptive title]

REFERENCE:
Drawing: [Sheet number, detail number]
Spec Section: [Section number]
Location: [Building area, grid lines]

QUESTION:
[Clear, specific question. One question per RFI.]

BACKGROUND:
[Explain why you need this information. What did you find? 
Why can't you proceed without an answer?]

SUGGESTED RESOLUTION:
[Provide your recommended solution. This speeds up response 
and shows you've thought it through.]

SCHEDULE IMPACT:
[Note if work is being delayed waiting for response]
Response needed by: [DATE]

ATTACHMENTS:
[ ] Marked-up drawing
[ ] Photo
[ ] Sketch
[ ] Other: ____________

Submitted by: _________________ Date: _________
```

## RFI Writing Tips

### Be Specific
❌ "The flashing detail is unclear."
✅ "Detail 5/A501 shows base flashing at 8" height, but the parapet is only 6" tall. Please confirm flashing height."

### Reference Documents
❌ "The drawings don't match the specs."
✅ "Drawing A501 Detail 5 shows TPO membrane, but Spec Section 07 52 00 specifies modified bitumen. Please clarify which system to install."

### Suggest Solutions
❌ "What should we do?"
✅ "We suggest installing the TPO system per Drawing A501 as this matches the approved submittal. Please confirm or advise."

### Note Impacts
❌ "Please respond soon."
✅ "Flashing material must be ordered by [DATE] to maintain schedule. Delayed response will impact the [DATE] completion milestone."

## Common Roofing RFI Topics

### Document Conflicts
- Drawing vs. spec membrane type
- Different insulation R-values shown
- Conflicting edge metal details
- Drawing scale doesn't match dimensions

### Missing Information
- Drain locations not shown
- Penetration sizes not indicated
- Curb dimensions missing
- Edge metal profile not specified

### Site Conditions
- Existing conditions differ from drawings
- Deck damage discovered
- Existing drains don't match new locations
- Structural issues found

### Scope Clarification
- Who installs blocking/nailers
- RTU removal and reset responsibility
- Extent of tear-off
- Edge of work boundaries

### Substitution Requests
- Alternate manufacturer
- Different membrane thickness
- Alternative attachment method

## RFI Response Tracking

```
| RFI # | Subject | Sent | Due | Rcvd | Status | Impact |
|-------|---------|------|-----|------|--------|--------|
| 001 | Drain location | 1/5 | 1/12 | 1/10 | Closed | None |
| 002 | Edge detail | 1/8 | 1/15 | - | Open | Delay |
| 003 | Blocking resp | 1/10| 1/17 | 1/20 | Closed | CO pending |
```

## Response Follow-Up

### If Response is Clear
- Implement as directed
- Document in daily log
- Update drawings if needed
- Close RFI

### If Response is Unclear
- Request clarification
- Reference original RFI
- Be specific about what's still unclear

### If Response Changes Scope
- Document cost impact
- Submit PCO/change order request
- Don't proceed until CO approved (if material cost)

### If No Response
- Send reminder at 7 days
- Escalate to PM/Super at 14 days
- Document delays in daily reports
- Note in schedule correspondence

## Sample RFIs

### Conflict RFI
```
SUBJECT: Membrane Type Clarification - Roof Area A

REFERENCE:
Drawing A501 - Roof Plan
Spec Section 07 54 00 - Thermoplastic Membrane Roofing
Spec Section 07 52 00 - Modified Bituminous Membrane Roofing

QUESTION:
Drawing A501 indicates "TPO ROOFING SYSTEM" for Roof Area A, 
however both Spec Section 07 54 00 (TPO) and Spec Section 
07 52 00 (Modified Bitumen) are included in the project manual.
Please confirm which roofing system is required for Roof Area A.

SUGGESTED RESOLUTION:
Install TPO system per Drawing A501 and Spec Section 07 54 00, 
as this matches our approved submittal dated [DATE].

SCHEDULE IMPACT:
Material order must be placed by [DATE] to maintain schedule.
Response needed by [DATE].
```

### Missing Information RFI
```
SUBJECT: Roof Drain Locations - Building B

REFERENCE:
Drawing A502 - Building B Roof Plan
Grid Lines C-F / 1-4

QUESTION:
Drawing A502 does not indicate roof drain locations for Building B.
Please provide drain locations and sizes, or confirm drains should 
be located at structural low points.

SUGGESTED RESOLUTION:
Based on the tapered insulation layout, we suggest locating (4) 
4" roof drains at approximate grid intersections C-2, C-3, E-2, 
and E-3. See attached sketch.

SCHEDULE IMPACT:
Drain locations needed to complete tapered insulation shop 
drawings. Response needed by [DATE] to maintain submittal schedule.

ATTACHMENTS:
[X] Sketch showing suggested drain locations
```

### Unforeseen Condition RFI
```
SUBJECT: Existing Deck Damage - Roof Area C

REFERENCE:
Drawing A501 - Roof Area C
Grid Lines A-D / 5-8

QUESTION:
During tear-off, we discovered approximately 200 SF of corroded 
metal deck at the northwest corner of Roof Area C. Deck is 
perforated and structurally compromised. Please advise how to 
proceed. See attached photos.

SUGGESTED RESOLUTION:
Option A: Replace damaged deck (by structural contractor)
Option B: Install 3/4" plywood overlay over affected area

SCHEDULE IMPACT:
Work in this area is stopped pending direction. Each day of 
delay impacts overall completion date.

ATTACHMENTS:
[X] Photos of damaged deck (4)
[X] Sketch showing extent of damage
```

## Questions to Ask User

1. "What's the specific issue or conflict you found?"
2. "What drawing or spec section does this reference?"
3. "Where in the building is this?"
4. "What do you think the answer should be?"
5. "Is work stopped waiting for this answer?"
6. "When do you need a response by?"
