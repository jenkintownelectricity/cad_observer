# Quality Control Skill

## Purpose
Create inspection checklists, document quality control procedures, and manage punch lists.

## When to Use
- User needs inspection checklists
- User needs to document QC procedures
- User is preparing for manufacturer inspection
- User needs to create or manage punch lists
- User asks about quality standards

## Inspection Points by Phase

### Pre-Installation
- [ ] Deck condition verified
- [ ] Deck dry and clean
- [ ] Blocking/nailers installed correctly
- [ ] Slope verified (to drains)
- [ ] Penetrations located and prepared
- [ ] Drains at low points
- [ ] Submittal approvals on site

### Insulation Installation
- [ ] Correct product per submittal
- [ ] Correct thickness/R-value
- [ ] Boards tight together
- [ ] Staggered joints (between layers)
- [ ] Fastener pattern correct
- [ ] No damaged boards
- [ ] Edges at walls/curbs fitted

### Membrane Installation
- [ ] Correct product per submittal
- [ ] Rolls aligned properly
- [ ] Seam overlaps correct (min 2.5-3")
- [ ] Seams welded/adhered fully
- [ ] No wrinkles or bridging
- [ ] No fishmouths
- [ ] Membrane relaxed before adhering

### Seam Quality
- [ ] Seam width consistent
- [ ] Full weld across seam
- [ ] No burn-through
- [ ] No cold welds
- [ ] Probe test passed
- [ ] T-patches at intersections

### Flashing
- [ ] Height per spec (min 8")
- [ ] Membrane to wall sealed
- [ ] Termination bar secured
- [ ] Sealant at top edge
- [ ] Inside/outside corners done
- [ ] No bridging at corners

### Penetrations
- [ ] Boots properly sized
- [ ] Seal at pipe/boot junction
- [ ] Metal flanges primed
- [ ] Membrane under flange
- [ ] Pipe support clamps (for large pipes)

### Drains
- [ ] Drain bowl set in sealant
- [ ] Clamping ring tight
- [ ] Leader connection watertight
- [ ] Strainer installed
- [ ] Sump area sloped to drain

### Edge Metal
- [ ] Correct profile per submittal
- [ ] Securely fastened
- [ ] Joints sealed
- [ ] Membrane under flange
- [ ] End dams at terminations
- [ ] Expansion joints where required

## Inspection Checklist Template

```
ROOFING QUALITY INSPECTION CHECKLIST

Project: _________
Date: _________
Inspector: _________
Area inspected: _________

DECK CONDITION (Before installation)
[ ] Clean and dry
[ ] Free of debris
[ ] No ponding water
[ ] Fastener holes repaired
[ ] Proper slope to drains
Notes: _________

INSULATION
[ ] Product matches submittal: _________
[ ] Thickness: _____ inches
[ ] Layers properly staggered
[ ] Tight joints
[ ] Fastener pattern: _________
Notes: _________

MEMBRANE
[ ] Product matches submittal: _________
[ ] Color: _________
[ ] Seam overlap: _____ inches
[ ] Seam integrity (probe test): [ ] Pass [ ] Fail
Notes: _________

FLASHINGS
[ ] Base flashing height: _____ inches
[ ] Termination sealed
[ ] Corners properly treated
[ ] Curbs fully flashed
Notes: _________

PENETRATIONS
[ ] All penetrations flashed
[ ] Boots sealed to pipe
[ ] Storm collars installed
Notes: _________

DRAINS
[ ] Drains at low points
[ ] Clamping ring secure
[ ] Strainers in place
Notes: _________

EDGE METAL
[ ] Profile matches submittal
[ ] Securely fastened
[ ] Joints sealed
Notes: _________

OVERALL RATING:
[ ] Acceptable
[ ] Acceptable with noted repairs
[ ] Not acceptable - rework required

ITEMS REQUIRING CORRECTION:
1. _________
2. _________
3. _________

Inspector signature: _________
Foreman acknowledgment: _________
```

## Seam Probe Test Protocol

```
SEAM INTEGRITY TEST PROCEDURE

1. Allow seam to cool (minimum 5 minutes)

2. Use blunt-end probe tool

3. Insert probe at seam edge at 45° angle

4. Apply moderate pressure while running
   along seam length

5. PASS: Probe does not separate seam

6. FAIL: Probe enters seam - mark for repair

DOCUMENTATION:
- Test minimum 10% of seams
- Random selection across roof
- Document location of tests
- Document any failures and repairs
```

## Punch List Format

```
ROOFING PUNCH LIST

Project: _________
Date: _________
Prepared by: _________
Walk with: _________

| # | Location | Description | Status | Complete |
|---|----------|-------------|--------|----------|
| 1 | Grid A-3 | Repair fismouth in seam | Open | [ ] |
| 2 | Curb #4 | Reseal termination bar | Open | [ ] |
| 3 | Drain #2 | Adjust strainer | Open | [ ] |
| 4 | Edge @ N | Caulk joint at corner | Open | [ ] |

PRIORITY:
H = High (water intrusion risk)
M = Medium (warranty issue)
L = Low (cosmetic)

SIGN-OFF:
Items completed: _________
Verified by: _________
Date: _________
```

## Pre-Inspection Checklist (Before Manufacturer Visit)

```
MANUFACTURER INSPECTION PREP

Project: _________
Inspection date: _________
Inspector: _________

DOCUMENTATION READY:
[ ] Approved submittals on site
[ ] Daily logs available
[ ] Material delivery receipts
[ ] Seam test documentation
[ ] Photos of covered work
[ ] Warranty application complete

ROOF WALK PREP:
[ ] All debris removed
[ ] Drains clear
[ ] No ponding water
[ ] All flashings complete
[ ] All penetrations flashed
[ ] Edge metal complete
[ ] Walkways installed (if required)

KNOWN ISSUES ADDRESSED:
[ ] _________
[ ] _________
[ ] _________

CONTACT INFO:
Superintendent on site: _________
Phone: _________
```

## Common Defects and Repairs

### Seam Defects
| Defect | Cause | Repair |
|--------|-------|--------|
| Cold weld | Insufficient heat | Cut out, patch |
| Burn-through | Too much heat | Patch over |
| Fishmouth | Air trapped | Cut, flatten, patch |
| Short seam | Missed edge | Add cover strip |

### Flashing Defects
| Defect | Cause | Repair |
|--------|-------|--------|
| Bridging | Not fitted to angle | Cut, reset |
| Open corner | Improper wrap | Add corner patch |
| Loose termination | Not fastened | Add fasteners, seal |

### Membrane Defects
| Defect | Cause | Repair |
|--------|-------|--------|
| Wrinkle | Not relaxed | May need to re-lay |
| Puncture | Foot traffic/dropped tool | Patch |
| Blister | Moisture trapped | Cut, dry, patch |

## Repair Documentation

```
REPAIR DOCUMENTATION

Date: _________
Location: _________
Defect type: _________

BEFORE (photo): _________

REPAIR METHOD:
_________

MATERIALS USED:
_________

AFTER (photo): _________

Repair performed by: _________
QC verification: _________
```

## Questions to Ask User

1. "What phase of installation are you inspecting?"
2. "What roofing system is installed?"
3. "Is this for internal QC or manufacturer inspection?"
4. "Are there known problem areas to address?"
5. "What documentation do you need to provide?"
