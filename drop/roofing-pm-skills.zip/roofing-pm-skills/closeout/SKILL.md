# Project Closeout Skill

## Purpose
Manage project closeout including warranty documentation, as-builts, O&M manuals, and final documentation.

## When to Use
- User is completing a project
- User needs closeout document templates
- User asks about warranty requirements
- User needs to prepare O&M manuals
- User needs final inspection checklists

## Closeout Checklist

### Pre-Closeout (2 weeks before completion)
- [ ] Schedule final punch walk
- [ ] Order warranty materials/documentation
- [ ] Compile as-built drawings
- [ ] Gather O&M documentation
- [ ] Schedule manufacturer final inspection
- [ ] Verify all change orders processed
- [ ] Confirm retention amount

### Final Week
- [ ] Complete punch list items
- [ ] Conduct final cleaning
- [ ] Remove all equipment and staging
- [ ] Final photos
- [ ] Manufacturer inspection passed
- [ ] Owner/GC final walk

### Closeout Documentation
- [ ] Warranty submitted/received
- [ ] As-built drawings submitted
- [ ] O&M manual submitted
- [ ] Final lien waiver
- [ ] Consent of surety (if bonded)
- [ ] Certificate of Substantial Completion
- [ ] Final payment application

## Warranty Documentation

### Warranty Request Form (to Manufacturer)
```
WARRANTY APPLICATION

Date: _________
Project: _________
Address: _________
Owner: _________
Contractor: _________
Contractor License #: _________

SYSTEM INFORMATION:
Membrane type: _________
Membrane thickness: _________
Color: _________
Square footage: _________

WARRANTY REQUESTED:
Type: [ ] Material only [ ] NDL [ ] Total System
Duration: _____ years
Wind speed: _____ mph

INSTALLATION DATES:
Start: _________
Complete: _________
Manufacturer inspection: _________

ATTACHMENTS:
[ ] Signed inspection report
[ ] Roof plan
[ ] Material receipts
[ ] Installer certification

Submitted by: _________
```

### Warranty Transmittal to Owner
```
WARRANTY TRANSMITTAL

Date: _________
To: _________
Project: _________

Enclosed please find the following warranty documentation:

[ ] Manufacturer warranty certificate
    Warranty #: _________
    Duration: _____ years
    Type: _________
    Effective date: _________
    Expiration date: _________

[ ] Contractor workmanship warranty
    Duration: _____ years

IMPORTANT WARRANTY INFORMATION:
- Warranty registration has been filed with manufacturer
- Annual maintenance is required to maintain warranty
- See enclosed maintenance requirements
- Contact information for warranty claims:
  Manufacturer: _________
  Contractor: _________

Please retain this document with your building records.

_________
[Signature]
```

## As-Built Drawings

### As-Built Requirements
- Show actual conditions (not designed)
- Mark any deviations from plans
- Include:
  - Actual drain locations
  - Penetration locations and sizes
  - Membrane seam layout
  - Edge metal details
  - Flashing details
  - Any field changes

### As-Built Markup Conventions
```
AS-BUILT DRAWING CONVENTIONS

RED = Deleted/removed items
GREEN = Added items
BLUE = Revised/relocated items

All dimensions in red are field verified.
Cloud all changes from original drawing.
Date and initial all revisions.
```

### As-Built Transmittal
```
AS-BUILT TRANSMITTAL

Date: _________
Project: _________
To: _________

Enclosed: As-built drawings

Sheet #: _____ Revision: _____
Sheet #: _____ Revision: _____
Sheet #: _____ Revision: _____

CHANGES FROM CONTRACT DOCUMENTS:
1. _________
2. _________
3. _________

Format: [ ] Paper [ ] PDF [ ] CAD files

Prepared by: _________
```

## O&M Manual Contents

### Roofing O&M Manual Index
```
OPERATIONS & MAINTENANCE MANUAL
ROOFING SYSTEM

Project: _________
Date: _________

TAB 1 - GENERAL INFORMATION
1.1 Project data sheet
1.2 Emergency contacts
1.3 System overview

TAB 2 - WARRANTY
2.1 Manufacturer warranty certificate
2.2 Contractor warranty
2.3 Warranty terms and conditions
2.4 Claim procedures

TAB 3 - MAINTENANCE REQUIREMENTS
3.1 Inspection schedule
3.2 Maintenance checklist
3.3 Cleaning procedures
3.4 Drain maintenance

TAB 4 - PRODUCT INFORMATION
4.1 Membrane data sheets
4.2 Insulation data sheets
4.3 Flashing product data
4.4 Sealant product data

TAB 5 - AS-BUILT DRAWINGS
5.1 Roof plan
5.2 Detail drawings

TAB 6 - CERTIFICATIONS
6.1 Manufacturer inspection report
6.2 Installer certifications

TAB 7 - REPAIR PROCEDURES
7.1 Emergency repair instructions
7.2 Approved repair materials
7.3 Contractor contact information
```

### Maintenance Requirements Template
```
ROOF MAINTENANCE REQUIREMENTS

PROJECT: _________
SYSTEM: _________
WARRANTY #: _________

SEMI-ANNUAL INSPECTION (Spring and Fall):

MEMBRANE:
[ ] Check for punctures, tears, or damage
[ ] Inspect seams for separation
[ ] Look for ponding water areas
[ ] Check for debris accumulation
[ ] Inspect for blistering or ridging

FLASHINGS:
[ ] Check base flashing for separation
[ ] Inspect termination bar and sealant
[ ] Check counter flashing condition
[ ] Inspect curb flashings
[ ] Check penetration seals

DRAINS:
[ ] Clear debris from drain bowls
[ ] Check strainers
[ ] Verify free flow
[ ] Inspect overflow drains

EDGE METAL:
[ ] Check for loose or missing fasteners
[ ] Inspect joints and sealant
[ ] Look for wind damage

ACCESSORIES:
[ ] Check walkway pads
[ ] Inspect equipment supports
[ ] Verify expansion joint function

DOCUMENTATION:
[ ] Record inspection date
[ ] Note any deficiencies
[ ] Schedule repairs
[ ] Keep records for warranty

CAUTION:
- No foot traffic except on walkway pads
- No storage of materials on roof
- No penetrations without contractor approval
- Report damage immediately

CONTRACTOR CONTACT:
Company: _________
Phone: _________
Email: _________
24-hour emergency: _________
```

## Final Lien Waiver

```
FINAL UNCONDITIONAL LIEN WAIVER

Date: _________
Project: _________
Owner: _________
Contractor: _________

Upon receipt of final payment in the amount of 
$_________, the undersigned waives and releases 
any and all lien rights, stop notice rights, and 
payment bond rights that the undersigned has on 
the above project.

This waiver covers all labor, materials, equipment, 
and services provided through the completion of 
the contract.

Final contract value: $_________
Total payments received: $_________
This payment: $_________

_________
Company name

_________
Authorized signature

_________
Title

_________
Date

[NOTARY SECTION IF REQUIRED]
```

## Certificate of Substantial Completion

```
CERTIFICATE OF SUBSTANTIAL COMPLETION

Project: _________
Owner: _________
Contractor: _________
Architect: _________

Date of Substantial Completion: _________

The work performed under this contract has been 
reviewed and found to be substantially complete.

The date of Substantial Completion is the date of 
commencement of warranties.

PUNCH LIST ITEMS:
[ ] None
[ ] See attached list (to be completed by _____)

Remaining work has an estimated value of: $_____

SIGNATURES:
Contractor: _________ Date: _____
Architect: _________ Date: _____
Owner: _________ Date: _____
```

## Final Payment Application

### Checklist Before Submitting
- [ ] All work complete (or punch list minimal)
- [ ] Warranties submitted
- [ ] As-builts submitted
- [ ] O&M manual submitted
- [ ] All change orders processed
- [ ] Lien waivers from all subs/suppliers
- [ ] Consent of surety (if bonded)
- [ ] Final inspection passed
- [ ] Keys/access devices returned
- [ ] Site cleaned

## Questions to Ask User

1. "Is all work complete including punch list?"
2. "Has the manufacturer inspection passed?"
3. "What warranty type is required?"
4. "Do you need to submit O&M manuals?"
5. "What closeout documents does the GC require?"
6. "Is the project bonded?"
