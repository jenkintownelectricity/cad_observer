# Safety Skill

## Purpose
Create Job Hazard Analyses (JHAs), toolbox talks, fall protection plans, and safety documentation for roofing projects.

## When to Use
- User needs to create a JHA for a task
- User needs a toolbox talk topic
- User needs fall protection planning
- User needs safety meeting documentation
- User asks about OSHA requirements

## OSHA Roofing Requirements (29 CFR 1926)

### Fall Protection (Subpart M)
- **6 feet trigger height** for construction
- Low-slope (≤4:12): guardrails, safety net, or personal fall arrest
- Steep slope (>4:12): guardrails, safety net, or personal fall arrest
- Holes must be covered or guarded
- Leading edges require fall protection

### Scaffolding (Subpart L)
- Guardrails at 6+ feet
- Fully planked platforms
- Safe access required
- Competent person inspection

### Ladders (Subpart X)
- 3-point contact
- Extend 3 feet above landing
- 4:1 angle ratio
- Secured at top

### PPE Requirements
- Hard hats (when overhead hazards)
- Safety glasses
- Work boots
- Gloves appropriate to task
- High-vis when near traffic

## Job Hazard Analysis (JHA)

### JHA Template
```
JOB HAZARD ANALYSIS

Date: _________      Project: _________
Task: _________      Prepared by: _________

| Step | Hazard | Control Measure |
|------|--------|-----------------|
| 1. Access roof | Falls from ladder | 3-point contact, ladder secured, extend 3' above roof |
| 2. Set up work area | Trips, falls | Clear debris, mark holes, establish perimeter |
| 3. Remove existing roof | Falls from edge | Warning line at 15', monitor at 6' from edge |
| | Cuts | Cut-resistant gloves, proper knife technique |
| | Back injury | Proper lifting, use carts |
| 4. Install insulation | Eye injury | Safety glasses, watch for wind |
| | Heat stress | Hydration, rest breaks, shade |
| 5. Install membrane | Burns (torch) | Hot work permit, fire watch, extinguisher |
| | Chemical exposure | Adhesive ventilation, gloves |
| 6. Flash penetrations | Falls from edge | Fall arrest when within 6' of edge |

REQUIRED PPE:
[ ] Hard hat
[ ] Safety glasses
[ ] Work boots
[ ] Gloves
[ ] High-vis vest
[ ] Fall arrest harness
[ ] Other: _________

EMERGENCY CONTACTS:
911 for emergencies
Supervisor: _________
Safety director: _________

Reviewed by crew: _________ Date: _________
```

## Fall Protection Plan

### Low-Slope Roof (<4:12)
```
FALL PROTECTION PLAN

Project: _________
Roof area: _________ SF
Roof height: _________ ft
Perimeter: _________ LF

FALL PROTECTION METHOD:
[ ] Warning line system (15' from edge)
[ ] Guardrail system
[ ] Personal fall arrest system
[ ] Safety monitor system (≤50' wide only)
[ ] Combination: _________

WARNING LINE SPECIFICATIONS:
- Stanchions at 6' max intervals
- Line at 34-39" height
- 500 lb minimum strength
- Flagged every 6'
- Set back 15' minimum from edge

PERSONAL FALL ARREST:
- Anchor points: [describe locations]
- Anchor capacity: 5,000 lbs per person
- Harness type: Full body
- Lanyard: 6' max with shock absorber
- Rescue plan: _________

CONTROLLED ACCESS ZONES:
[For leading edge work]
- Between warning line and edge
- Only trained workers
- Safety monitor required

COMPETENT PERSON: _________
```

### Fall Protection Equipment Checklist
```
FALL PROTECTION INSPECTION

Date: _________
Inspector: _________

HARNESS (Each worker):
[ ] Labels legible
[ ] No cuts, tears, or abrasion
[ ] Buckles function
[ ] D-ring not bent
[ ] Stitching intact

LANYARDS:
[ ] No cuts or fraying
[ ] Shock absorber not deployed
[ ] Snaphooks lock properly
[ ] Within inspection date

ANCHORS:
[ ] Installed properly
[ ] 5,000 lb capacity verified
[ ] Location appropriate
[ ] No visible damage

SELF-RETRACTING LIFELINES:
[ ] Retracts smoothly
[ ] Locks on quick pull
[ ] Housing not cracked
[ ] Annual inspection current
```

## Toolbox Talks

### Heat Stress
```
TOOLBOX TALK: Heat Stress Prevention

Date: _________
Project: _________
Presented by: _________

KEY POINTS:
1. Recognize symptoms:
   - Heavy sweating (or no sweating)
   - Weakness, confusion
   - Nausea, dizziness
   - Hot, red skin
   - Fast heartbeat

2. Prevention:
   - Drink water every 15-20 minutes
   - Take breaks in shade
   - Wear light, loose clothing
   - Watch out for each other
   - Know where first aid is

3. What to do:
   - Move to shade/cool area
   - Loosen clothing
   - Apply cool water
   - Call for help if severe

CREW SIGNATURES:
_______________  _______________
_______________  _______________
_______________  _______________
```

### Fall Protection
```
TOOLBOX TALK: Fall Protection

Date: _________
Project: _________
Presented by: _________

KEY POINTS:
1. Today's fall protection plan:
   [Describe specific system being used]

2. Anchor points:
   [Where they are located]

3. 100% tie-off:
   - Always connected when within 6' of edge
   - Use two lanyards when moving
   - Never disconnect without second connection

4. Equipment inspection:
   - Inspect before each use
   - Report any damage
   - Don't use damaged equipment

5. Rescue plan:
   [How we will rescue a fallen worker]

CREW SIGNATURES:
_______________  _______________
_______________  _______________
_______________  _______________
```

### Hot Work (Torching)
```
TOOLBOX TALK: Hot Work Safety

Date: _________
Project: _________
Presented by: _________

KEY POINTS:
1. Hot work permit:
   - Required before torching
   - Posted at work area
   - Lists all precautions

2. Fire watch:
   - Dedicated person during work
   - Continue 30 min after work stops
   - Has extinguisher and communication

3. Fire extinguisher:
   - Within 25 feet
   - Fully charged
   - Everyone knows location

4. Combustibles:
   - Clear area of debris
   - Cover anything that can't move
   - Check below deck for combustibles

5. Emergency:
   - Know alarm location
   - Know exit routes
   - 911 first, then supervisor

CREW SIGNATURES:
_______________  _______________
_______________  _______________
_______________  _______________
```

## Hot Work Permit

```
HOT WORK PERMIT

Date: _________  Valid: _____ to _____
Location: _________
Type of work: [ ] Torch  [ ] Weld  [ ] Cut

BEFORE WORK:
[ ] Area clear of combustibles (35' radius)
[ ] Fire extinguisher present (ABC type)
[ ] Fire watch assigned: _________
[ ] Smoke detectors disabled (with facility approval)
[ ] Sprinklers functional
[ ] Area below checked
[ ] Covers/shields in place

DURING WORK:
[ ] Fire watch maintained
[ ] Only trained operators
[ ] Equipment in good condition

AFTER WORK:
[ ] Fire watch continues 30 minutes
[ ] Area inspected for hot spots
[ ] Cylinders secured
[ ] Smoke detectors restored

Authorized by: _________
Fire watch: _________
Operator: _________
```

## Weekly Safety Meeting Log

```
WEEKLY SAFETY MEETING

Date: _________
Project: _________
Attendees: _________

TOPICS COVERED:
1. _________
2. _________
3. _________

INCIDENTS/NEAR MISSES THIS WEEK:
_________

HAZARDS IDENTIFIED:
_________

CORRECTIVE ACTIONS:
_________

NEXT WEEK'S FOCUS:
_________

Meeting conducted by: _________
```

## Incident Report Form

```
INCIDENT REPORT

Date/Time: _________
Location: _________
Project: _________

TYPE OF INCIDENT:
[ ] Injury    [ ] Near miss
[ ] Property damage    [ ] Environmental

PERSONS INVOLVED:
Name: _________
Role: _________

DESCRIPTION:
What happened:
_________

Contributing factors:
_________

INJURY DETAILS (if applicable):
Body part: _________
Type of injury: _________
Treatment: _________

CORRECTIVE ACTIONS:
Immediate: _________
Long-term: _________

Report prepared by: _________
Supervisor review: _________
Date: _________
```

## Questions to Ask User

1. "What specific task needs a JHA?"
2. "What's the roof height and slope?"
3. "What fall protection method are you using?"
4. "Is there any hot work (torching)?"
5. "Any site-specific hazards to address?"
6. "What PPE is required by the GC?"
