# Bid Preparation Skill

## Purpose
Help prepare professional roofing bid proposals, scope letters, and pricing documents.

## When to Use
- User needs to write a bid proposal or scope letter
- User asks for help pricing a job
- User needs to clarify inclusions/exclusions
- User wants to review bid language

## Inputs Needed
1. **Project info** - Name, location, GC, owner
2. **Scope** - What work is included
3. **Quantities** - From takeoff
4. **Pricing** - Material costs, labor rates
5. **Timeline** - Required start/completion dates

## Bid Components

### 1. Cover Letter
- Company letterhead
- Date and bid number
- Project name and location
- GC/Owner contact
- Brief scope summary
- Total price
- Signature

### 2. Scope of Work
- Detailed description of work
- System description
- Manufacturer/products
- Warranty offered

### 3. Inclusions
Explicitly state what IS included:
- Mobilization/demobilization
- Material delivery
- Equipment (cranes, lifts, etc.)
- Labor and supervision
- Manufacturer inspections
- Permits (if applicable)
- Warranty documentation

### 4. Exclusions
Explicitly state what is NOT included:
- Structural repairs
- Wood blocking/nailers
- Electrical disconnects
- HVAC removal/reset
- Hazmat/asbestos abatement
- Winter conditions premium
- After-hours work
- Permits (if by GC)

### 5. Clarifications
- Access assumptions
- Staging area requirements
- Work sequence
- Interface with other trades
- Weather days

### 6. Alternates
- Add/deduct pricing for options
- Different systems
- Extended warranties

### 7. Schedule
- Duration
- Crew size
- Start date requirements

## Pricing Structure

### Labor Pricing
```
Total Labor Hours × Burdened Labor Rate = Labor Cost

Burdened rate includes:
- Base wage
- Benefits (health, pension)
- Payroll taxes
- Workers comp
- Union dues (if applicable)
```

### Material Pricing
```
Material cost + Tax + Freight = Total Materials
Add markup: 10-20% typical
```

### Equipment Pricing
```
Crane: $XXX/day × days
Lift: $XXX/week × weeks
Small tools: allowance
```

### Overhead & Profit
```
Typical markup structure:
- Direct costs (labor + materials + equipment)
- + General conditions (5-10%)
- + Overhead (10-15%)
- + Profit (5-15%)
```

## Scope Letter Template

```
[COMPANY LETTERHEAD]

Date: [DATE]
Bid #: [BID NUMBER]

[GC NAME]
[ADDRESS]
[CITY, STATE ZIP]

Attn: [CONTACT NAME]

RE: [PROJECT NAME]
    [PROJECT ADDRESS]
    Roofing Scope

Dear [NAME],

[COMPANY NAME] is pleased to submit our proposal for the roofing 
scope of work for the above-referenced project.

BASE BID: $[AMOUNT]

SCOPE OF WORK:
Furnish all labor, materials, and equipment necessary to complete 
the following:

[BUILDING/AREA NAME] - [XX,XXX] SF
- Remove existing roofing system to deck
- Install [MANUFACTURER] [SYSTEM] roofing system consisting of:
  • [INSULATION DESCRIPTION]
  • [MEMBRANE DESCRIPTION]
  • [WARRANTY TYPE] warranty
- Install new roof drains ([XX] ea)
- Flash all penetrations, curbs, and walls
- Install new edge metal and coping

INCLUSIONS:
• Mobilization and demobilization
• Dumpsters for tear-off debris
• Manufacturer inspections
• [XX]-year [WARRANTY TYPE] warranty
• As-built drawings

EXCLUSIONS:
• Structural repairs or replacement
• Wood blocking and nailers (by others)
• Electrical disconnects (by others)
• Hazardous material abatement
• Work outside normal business hours
• Permits (by GC)
• Winter weather protection

CLARIFICATIONS:
• Pricing based on normal 40-hour work week
• Adequate staging area with ground-level access required
• Roof access via exterior ladder or lift
• [XX] working days duration, weather permitting
• Price valid for 30 days

ALTERNATES:
Add #1: [DESCRIPTION] .......................... Add $[AMOUNT]
Deduct #1: [DESCRIPTION] ....................... Deduct $[AMOUNT]

Please contact us with any questions.

Respectfully submitted,

[NAME]
[TITLE]
[PHONE]
[EMAIL]
```

## Exclusion Language Library

### Structural
- "Structural repairs, reinforcement, or replacement"
- "Wood blocking, nailers, and cant strips (by others)"
- "Metal deck repairs or replacement"
- "Concrete repairs or leveling"

### Other Trades
- "Electrical disconnects and reconnects"
- "HVAC equipment removal, storage, and reset"
- "Plumbing modifications"
- "Lightning protection system modifications"

### Site Conditions
- "Hazardous material testing, abatement, or disposal"
- "Lead paint removal or encapsulation"
- "Asbestos-containing material handling"
- "PCB-containing caulk removal"

### Access/Logistics
- "Hoisting or crane services beyond [X] stories"
- "Material storage off-site"
- "Security escorts or badging fees"
- "Parking fees"

### Schedule
- "Premium time for work outside normal hours (7am-5pm M-F)"
- "Winter weather protection or heating"
- "Acceleration costs"
- "Extended general conditions beyond [X] weeks"

### Financial
- "Payment and performance bonds"
- "Permits and inspection fees"
- "Sales tax on materials"
- "Prevailing wage or certified payroll requirements"

## Red Flags to Watch For

### In Bid Documents
- Unrealistic schedule
- Ambiguous scope boundaries
- Missing details (membrane type, insulation R-value)
- Conflicting information between drawings and specs
- Liquidated damages clauses
- Indemnification language
- Pay-when-paid provisions

### Questions to Ask Before Bidding
1. "Who installs the blocking/nailers?"
2. "What's the work schedule?" (Night work, weekends)
3. "Is there an existing roof warranty to maintain?"
4. "Are there any known hazmat conditions?"
5. "What access is available?" (Ladders, interior, crane)
6. "Is the building occupied during construction?"

## Alternate Pricing Guidance

### System Upgrades
- 80 mil vs 60 mil TPO: Add $0.30-0.50/SF
- 20-year vs 15-year warranty: Add $0.15-0.25/SF
- Additional insulation layer: Add $0.40-0.60/SF per inch

### Scope Changes
- Add tear-off: Add $1.00-2.00/SF (varies by existing system)
- Add tapered insulation: Add $1.50-3.00/SF
- Add walkway pads: Add $3.00-5.00/SF

### Warranty Upgrades
- Standard to NDL: Add $0.10-0.20/SF
- NDL to Total System: Add $0.05-0.15/SF
