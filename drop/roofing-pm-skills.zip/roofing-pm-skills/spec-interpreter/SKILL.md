# Specification Interpreter Skill

## Purpose
Parse and interpret Division 07 specifications, identify requirements, flag conflicts, and extract actionable information.

## When to Use
- User uploads a spec section
- User asks about spec requirements
- User needs to verify product compliance
- User has questions about submittal requirements

## Division 07 Structure

### Section Numbering
```
07 00 00 - Thermal and Moisture Protection
├── 07 10 00 - Dampproofing and Waterproofing
│   ├── 07 11 00 - Dampproofing
│   ├── 07 12 00 - Built-up Bituminous Waterproofing
│   ├── 07 13 00 - Sheet Waterproofing
│   ├── 07 14 00 - Fluid-Applied Waterproofing
│   ├── 07 16 00 - Cementitious Waterproofing
│   ├── 07 17 00 - Bentonite Waterproofing
│   └── 07 18 00 - Traffic Coatings
│
├── 07 20 00 - Thermal Protection
│   ├── 07 21 00 - Thermal Insulation
│   ├── 07 22 00 - Roof and Deck Insulation
│   ├── 07 25 00 - Weather Barriers
│   ├── 07 26 00 - Vapor Retarders
│   └── 07 27 00 - Air Barriers
│
├── 07 30 00 - Steep Slope Roofing
│   ├── 07 31 00 - Shingles and Shakes
│   └── 07 32 00 - Roof Tiles
│
├── 07 50 00 - Membrane Roofing
│   ├── 07 51 00 - Built-Up Bituminous Roofing
│   ├── 07 52 00 - Modified Bituminous Membrane Roofing
│   ├── 07 53 00 - Elastomeric Membrane Roofing (EPDM)
│   ├── 07 54 00 - Thermoplastic Membrane Roofing (TPO/PVC)
│   ├── 07 55 00 - Protected Membrane Roofing
│   └── 07 56 00 - Fluid-Applied Roofing
│
├── 07 60 00 - Flashing and Sheet Metal
│   ├── 07 61 00 - Sheet Metal Roofing
│   ├── 07 62 00 - Sheet Metal Flashing and Trim
│   └── 07 65 00 - Flexible Flashing
│
├── 07 70 00 - Roof and Wall Specialties
│   ├── 07 71 00 - Roof Specialties
│   ├── 07 72 00 - Roof Accessories
│   └── 07 76 00 - Roof Pavers
│
└── 07 90 00 - Joint Protection
    ├── 07 91 00 - Preformed Joint Seals
    ├── 07 92 00 - Joint Sealants
    └── 07 95 00 - Expansion Control
```

## Spec Section Format (CSI 3-Part)

### Part 1 - General
**Look for:**
- Related documents
- Summary of work
- Submittals required
- Quality assurance requirements
- Delivery/storage requirements
- Warranty requirements
- Project conditions

**Key items to extract:**
- Pre-installation meeting requirements
- Manufacturer qualifications
- Installer qualifications
- Mock-up requirements
- Warranty duration and type

### Part 2 - Products
**Look for:**
- Manufacturers (approved or basis of design)
- System/product descriptions
- Material specifications
- Accessories
- Performance criteria

**Key items to extract:**
- Approved manufacturers (or "or equal")
- Membrane type and thickness
- Insulation type and R-value
- Fastener requirements
- Flashing materials
- Color selections

### Part 3 - Execution
**Look for:**
- Examination requirements
- Preparation
- Installation procedures
- Field quality control
- Protection
- Cleaning

**Key items to extract:**
- Substrate requirements
- Temperature limitations
- Inspection requirements
- Testing requirements

## Spec Parsing Checklist

### Submittal Requirements
- [ ] Product data sheets
- [ ] Shop drawings
- [ ] Samples
- [ ] Manufacturer certificates
- [ ] Installer qualifications
- [ ] Warranty documentation
- [ ] Maintenance manuals

### Quality Assurance
- [ ] Manufacturer qualifications (years in business, etc.)
- [ ] Installer qualifications (certified, trained, etc.)
- [ ] Pre-installation meeting required?
- [ ] Mock-up required?
- [ ] Third-party inspection required?

### Products
- [ ] Membrane manufacturer/type/thickness
- [ ] Insulation type/thickness/R-value
- [ ] Attachment method (adhered/mechanical/ballast)
- [ ] Flashing type (sheet vs. liquid)
- [ ] Edge metal gauge and profile
- [ ] Fastener type and pattern
- [ ] Sealant type

### Warranty
- [ ] Warranty duration
- [ ] Warranty type (material only, NDL, total system)
- [ ] Wind speed coverage
- [ ] Ponding water exclusion?
- [ ] Maintenance requirements

## Common Spec Language Decoded

### "Or Equal"
- Can substitute with architect approval
- Must submit comparison data
- Performance must match or exceed

### "No Substitutions"
- Use specified product only
- RFI required for any changes

### "Basis of Design"
- This manufacturer was used to design
- Others acceptable if equivalent
- Burden of proof on contractor

### "Approved Manufacturers"
- Use only listed manufacturers
- No substitutions without approval

### "As Directed by Architect"
- Requires clarification
- Get it in writing

### "Per Manufacturer's Recommendations"
- Follow current published instructions
- Document version used

### "ASTM [Number]"
- Material must meet this standard
- Request test reports

### "FM Approved" / "UL Listed"
- System must have current approval
- Verify approval number

## Conflict Detection

### Common Conflicts
1. **Spec vs. Drawings**
   - Different insulation thickness
   - Different membrane type
   - Different edge detail

2. **Spec vs. Spec**
   - Conflicting requirements between sections
   - General conditions vs. technical specs

3. **Unrealistic Requirements**
   - Install temperature limits not achievable
   - Schedule vs. cure time requirements
   - Conflicting warranty requirements

### Resolution Priority (typical)
1. Addenda (most recent first)
2. Specifications
3. Drawings (larger scale over smaller)
4. General conditions

## Warranty Types Explained

### Material Only
- Covers manufacturing defects
- Does NOT cover workmanship
- Shortest/cheapest option

### No Dollar Limit (NDL)
- Covers materials AND labor
- No cap on repair costs
- Manufacturer responsibility

### Total System
- NDL + consequential damages
- Covers interior damage
- Highest level coverage

### Key Warranty Terms
- **Prorated**: Coverage decreases over time
- **Non-prorated**: Full coverage for duration
- **Transferable**: Can transfer to new owner
- **Wind speed**: Coverage limit in MPH

## Questions to Ask About Specs

1. "Is there a spec section I should review for [specific item]?"
2. "The spec calls for [X] but the drawings show [Y] - which governs?"
3. "Can I substitute [product] for [specified product]?"
4. "What are the submittal requirements for this section?"
5. "What warranty is required and by whom?"

## Output Format

When analyzing a spec, provide:

```
SPEC ANALYSIS: [Section Number] - [Title]

MANUFACTURERS:
- Approved: [List]
- Basis of Design: [If specified]
- Substitutions: [Allowed/Not Allowed]

SYSTEM REQUIREMENTS:
- Membrane: [Type, thickness, color]
- Insulation: [Type, R-value, layers]
- Attachment: [Method]
- Wind Uplift: [Rating required]

SUBMITTALS REQUIRED:
- [ ] Product data
- [ ] Shop drawings
- [ ] Samples
- [ ] Certificates
- [ ] Warranty draft

QUALITY ASSURANCE:
- Pre-install meeting: [Yes/No]
- Mock-up: [Yes/No]
- Third-party inspection: [Yes/No]
- Installer certification: [Requirements]

WARRANTY:
- Duration: [Years]
- Type: [Material/NDL/Total System]
- Wind: [MPH]
- Special conditions: [Note any]

POTENTIAL ISSUES:
- [Flag any conflicts, ambiguities, or concerns]

QUESTIONS FOR ARCHITECT:
- [List RFI candidates]
```
