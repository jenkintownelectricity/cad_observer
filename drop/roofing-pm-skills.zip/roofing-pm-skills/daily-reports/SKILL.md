# Daily Reports Skill

## Purpose
Document daily progress, conditions, and events for project records, payment applications, and dispute resolution.

## When to Use
- User needs daily report templates
- User asks about what to document
- User needs to track progress
- User needs weather delay documentation

## Why Daily Reports Matter

1. **Payment documentation** - Proves work completed
2. **Delay claims** - Documents weather, access issues
3. **Change orders** - Records unforeseen conditions
4. **Disputes** - Legal documentation
5. **Progress tracking** - Keeps schedule accurate

## Daily Report Template

```
DAILY CONSTRUCTION REPORT

Date: _________           Day: [ ]M [ ]T [ ]W [ ]Th [ ]F [ ]S [ ]Su
Project: _________        Report #: _________
Foreman: _________

WEATHER CONDITIONS
Morning:    Temp: _____°F   [ ]Clear [ ]Cloudy [ ]Rain [ ]Snow
Afternoon:  Temp: _____°F   [ ]Clear [ ]Cloudy [ ]Rain [ ]Snow
Wind: _____mph            [ ]Work day [ ]Weather day

MANPOWER
| Name | Classification | Hours | Area |
|------|----------------|-------|------|
| | Foreman | | |
| | Journeyman | | |
| | Journeyman | | |
| | Journeyman | | |
| | Apprentice | | |
| TOTAL | | | |

WORK PERFORMED TODAY
Area/Location: _________
Description: _________
Quantity completed: _________ SF/LF

Area/Location: _________
Description: _________
Quantity completed: _________ SF/LF

EQUIPMENT ON SITE
| Equipment | Hours/Use |
|-----------|-----------|
| | |
| | |

MATERIALS RECEIVED
| Material | Quantity | Delivery ticket # |
|----------|----------|-------------------|
| | | |
| | | |

MATERIALS INSTALLED
| Material | Quantity | Location |
|----------|----------|----------|
| | | |
| | | |

VISITORS/INSPECTIONS
| Name | Company | Purpose | Time |
|------|---------|---------|------|
| | | | |

SAFETY
[ ] Toolbox talk conducted - Topic: _________
[ ] JHA reviewed
[ ] No incidents
[ ] Incident occurred - Report #: _________

DELAYS/ISSUES
[ ] None
[ ] Weather delay: _____ hours
[ ] Access delay: _____ hours
[ ] Material delay: _____ hours
[ ] Other trade interference: _________
[ ] Other: _________

NOTES/COMMENTS:
_________

PHOTOS TAKEN: [ ]Yes [ ]No
Photo log #: _________

TOMORROW'S PLAN:
_________

Submitted by: _________
Date/Time: _________
```

## Progress Tracking

### Percentage Complete by Area
```
PROGRESS SUMMARY

Date: _________

| Area | Total SF | Complete SF | % Complete |
|------|----------|-------------|------------|
| Area A | 25,000 | 25,000 | 100% |
| Area B | 30,000 | 22,500 | 75% |
| Area C | 15,000 | 3,750 | 25% |
| TOTAL | 70,000 | 51,250 | 73% |
```

### Phase Progress
```
| Phase | Complete |
|-------|----------|
| Mobilization | 100% |
| Tear-off | 100% |
| Deck repair | 100% |
| Insulation | 85% |
| Membrane | 60% |
| Flashing | 40% |
| Edge metal | 25% |
| Cleanup | 0% |
| OVERALL | 62% |
```

## Weather Documentation

### Weather Day Criteria
Document clearly when weather prevents work:
- Rain during installation
- Temperature below product minimums
- High winds (typically >25-30 mph)
- Wet deck surface
- Snow/ice conditions

### Weather Delay Record
```
WEATHER DELAY DOCUMENTATION

Date: _________
Project: _________

CONDITIONS:
Temperature: _____°F
Precipitation: [ ]Rain [ ]Snow [ ]None
Wind: _____mph
Deck condition: [ ]Dry [ ]Wet [ ]Ice

IMPACT:
[ ] Full day lost
[ ] Partial day lost: _____ hours
[ ] Work continued in protected area

REASON WORK COULD NOT PROCEED:
[ ] Temperature below ___°F minimum for [product]
[ ] Active precipitation
[ ] Wet/ice deck surface
[ ] Wind exceeds safe working conditions

MITIGATION ATTEMPTED:
_________

Documented by: _________
```

## Photo Documentation

### Daily Photo Log
```
PHOTO LOG

Date: _________
Project: _________
Photographer: _________

| Photo # | Time | Location | Description |
|---------|------|----------|-------------|
| 001 | 7:00 | Overview | Morning start |
| 002 | 8:30 | Area B | Tear-off progress |
| 003 | 10:15 | Grid C-5 | Deck damage found |
| 004 | 12:00 | Area B | Insulation install |
| 005 | 3:30 | Overview | End of day |

PHOTOS UPLOADED TO: _________
```

### What to Photograph
- **Start of day** - Overview conditions
- **Work in progress** - Each major phase
- **Covered conditions** - Before covering (deck, insulation)
- **Problem areas** - Damage, issues found
- **Completed work** - Before leaving area
- **End of day** - Overview of day's progress
- **Material deliveries** - Condition on arrival
- **Safety** - Setup, meetings

## Weekly Summary Report

```
WEEKLY PROGRESS SUMMARY

Week ending: _________
Project: _________

PRODUCTION THIS WEEK:
| Activity | Planned | Actual | Variance |
|----------|---------|--------|----------|
| Tear-off | 5,000 SF| 4,500 SF| -500 SF |
| Insulation| 5,000 SF| 5,200 SF| +200 SF |
| Membrane | 4,000 SF| 3,800 SF| -200 SF |

MANPOWER:
Total man-hours: _________
Average crew size: _________

WEATHER:
Work days: _________
Weather days: _________
Weather hours lost: _________

SCHEDULE STATUS:
[ ] On schedule
[ ] Ahead by _____ days
[ ] Behind by _____ days
Reason: _________

SAFETY:
Incidents: _________
Near misses: _________
Toolbox talks: _________

ISSUES/CONCERNS:
_________

NEXT WEEK'S PLAN:
_________

Prepared by: _________
```

## Material Tracking

### Material Received Log
```
MATERIAL RECEIVING LOG

Date: _________

| Date | Material | Qty | Supplier | Ticket # | Condition |
|------|----------|-----|----------|----------|-----------|
| | | | | | |
| | | | | | |

Condition codes: G=Good, D=Damaged, S=Short
```

### Material Installed Log
```
MATERIAL INSTALLATION LOG

Week of: _________

| Date | Material | Qty | Location | Remaining |
|------|----------|-----|----------|-----------|
| | TPO rolls | 5 | Area B | 45 |
| | Polyiso | 50 bd | Area B | 150 |
| | Adhesive | 5 gal | Area B | 45 gal |
```

## Best Practices

### Do Document:
- Actual hours worked (not scheduled)
- Quantities completed
- All visitors and inspections
- Weather conditions at start and end of day
- Any delays or interference
- Safety activities
- Material deliveries and usage
- Photos of covered work

### Don't Forget:
- Sign and date every report
- Be factual, not editorial
- Note what you DIDN'T do and why
- Keep copies of everything
- Submit reports same day

### Common Mistakes:
- Vague descriptions ("worked on roof")
- Missing quantities
- No weather documentation
- Unsigned reports
- Submitted late

## Questions to Ask User

1. "What work was completed today?"
2. "How many crew members and hours?"
3. "Any weather impacts?"
4. "Any delays or issues?"
5. "What's planned for tomorrow?"
6. "Any materials delivered or problems?"
