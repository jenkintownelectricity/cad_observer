# Scheduling Skill

## Purpose
Create and manage roofing project schedules, coordinate with other trades, and track progress.

## When to Use
- User needs to create a project schedule
- User asks about sequencing
- User needs to update schedule
- User needs to communicate delays
- User needs to plan crew assignments

## Roofing Work Sequence

### Typical Sequence (New Construction)
1. Structural deck complete and accepted
2. Blocking and nailers installed (by others)
3. Mobilize and stage materials
4. Install vapor retarder (if required)
5. Install insulation (first layer)
6. Install insulation (second layer / cover board)
7. Install membrane - field
8. Install membrane - flashings
9. Install drains and penetration flashings
10. Install edge metal and coping
11. Install walkways and accessories
12. Cleanup and punchlist
13. Manufacturer inspection
14. Final inspection and warranty

### Typical Sequence (Reroof)
1. Pre-construction meeting
2. Mobilize equipment and dumpsters
3. Protect adjacent areas
4. Remove existing roofing system
5. Inspect and repair deck
6. [New construction sequence from step 4]

## Duration Estimating

### Production Rates (per crew of 5)
| Task | Rate | Unit |
|------|------|------|
| Tear-off (single ply) | 5,000 | SF/day |
| Tear-off (BUR) | 3,000 | SF/day |
| Tear-off (ballast removal) | 8,000 | SF/day |
| Insulation (1 layer) | 8,000 | SF/day |
| Insulation (2 layers) | 6,000 | SF/day |
| TPO adhered | 4,000 | SF/day |
| TPO mechanical | 5,000 | SF/day |
| EPDM adhered | 4,000 | SF/day |
| Mod-bit torch | 3,000 | SF/day |
| Base flashing | 300 | LF/day |
| Edge metal | 400 | LF/day |
| Coping | 300 | LF/day |

### Duration Formula
```
Work days = Quantity ÷ (Crew size × Production rate per person)

Example: 50,000 SF TPO adhered
- Production: 4,000 SF/day with 5-man crew
- Duration: 50,000 ÷ 4,000 = 12.5 days → 13 days

Add weather factor: 13 × 1.15 = 15 days
```

### Weather Factors by Season
| Season | Location | Factor |
|--------|----------|--------|
| Spring | Northeast | 1.20 |
| Summer | Northeast | 1.10 |
| Fall | Northeast | 1.15 |
| Winter | Northeast | 1.50+ |
| Year-round | Southeast | 1.15 |
| Year-round | Southwest | 1.05 |

## Schedule Format

### Bar Chart (Simple)
```
ROOFING SCHEDULE - [PROJECT NAME]
Start: [DATE]  |  Duration: [XX] Days  |  Completion: [DATE]

Week 1          Week 2          Week 3          Week 4
M T W T F      M T W T F      M T W T F      M T W T F
──────────────────────────────────────────────────────────
Mobilize        ██
Tear-off        ██████████
Deck repair         ████
Insulation              ██████████
Membrane                      ████████████
Flashing                              ████████
Edge metal                                  ████
Cleanup/Punch                                   ██
Inspection                                       ▲
```

### Detailed Schedule Template
```
ACTIVITY SCHEDULE

| ID | Activity | Duration | Start | Finish | Predecessor |
|----|----------|----------|-------|--------|-------------|
| 1 | Mobilization | 1 day | Mon 6/1 | Mon 6/1 | - |
| 2 | Staging | 1 day | Tue 6/2 | Tue 6/2 | 1 |
| 3 | Protection | 1 day | Tue 6/2 | Tue 6/2 | 1 |
| 4 | Tear-off Area A | 5 days | Wed 6/3 | Tue 6/9 | 2,3 |
| 5 | Deck repair | 2 days | Wed 6/10| Thu 6/11| 4 |
| 6 | Insulation Area A| 4 days | Fri 6/12| Wed 6/17| 5 |
| 7 | Membrane Area A | 5 days | Thu 6/18| Wed 6/24| 6 |
| 8 | Flashing Area A | 3 days | Thu 6/25| Mon 6/29| 7 |
| 9 | Tear-off Area B | 5 days | Thu 6/18| Wed 6/24| 4 |
| 10| Insulation Area B| 4 days | Thu 6/25| Tue 6/30| 9 |
...
```

## Crew Planning

### Crew Composition
```
Standard 5-Man Crew:
- 1 Foreman
- 4 Journeymen

Large Job (8-Man):
- 1 Foreman
- 1 Leadman
- 6 Journeymen

Split Crews (2 × 4):
- 1 Foreman (floats)
- 2 Leadmen
- 5 Journeymen
```

### Crew Assignment Matrix
```
Week of: _______________

          | Mon | Tue | Wed | Thu | Fri |
----------|-----|-----|-----|-----|-----|
Project A | 5   | 5   | 5   | 5   | 5   |
Project B | 4   | 4   | 4   | 4   | 4   |
Project C | -   | -   | 3   | 3   | 3   |
Service   | 2   | 2   | 2   | 2   | 2   |
----------|-----|-----|-----|-----|-----|
TOTAL     | 11  | 11  | 14  | 14  | 14  |
Available | 15  | 15  | 15  | 15  | 15  |
```

## Material Delivery Schedule

### Lead Times
| Material | Lead Time |
|----------|-----------|
| Standard membrane | 3-5 days |
| Custom color membrane | 2-3 weeks |
| Standard insulation | 1-2 days |
| Tapered insulation | 2-3 weeks |
| Standard edge metal | 1 week |
| Custom sheet metal | 2-3 weeks |
| Roof drains | 1-2 weeks |

### Delivery Planning
```
DELIVERY SCHEDULE

| Material | Qty | Order By | Deliver | Location |
|----------|-----|----------|---------|----------|
| TPO rolls | 50 | 5/20 | 5/28 | Staging A |
| Polyiso 2.5" | 200 bd| 5/22 | 5/29 | Roof |
| Cover board | 150 bd| 5/22 | 5/29 | Roof |
| Adhesive | 50 gl | 5/22 | 5/29 | Staging A |
| Edge metal | 500 LF| 5/15 | 6/5 | Staging B |
```

## Weather Monitoring

### Installation Temperature Limits
| Product | Min Temp | Notes |
|---------|----------|-------|
| TPO welding | 40°F | Slower welding at low temp |
| EPDM adhesive | 40°F | Warmer for primer/adhesive |
| Mod-bit torch | 25°F | Can torch in cold |
| Mod-bit cold | 45°F | Adhesive requires warmth |
| Sealants | 40°F | Varies by product |

### Rain Protocol
- Monitor weather daily
- Secure all open work before rain
- No installation on wet surfaces
- Allow drying time after rain
- Document weather delays

## Delay Communication

### Delay Notice Format
```
SCHEDULE DELAY NOTICE

Date: _________
Project: _________
To: [GC]

This notice documents a delay to the roofing schedule:

CAUSE OF DELAY:
[ ] Weather - [description]
[ ] Predecessor work not complete - [description]
[ ] Access denied - [description]
[ ] Material delay - [description]
[ ] Other trade interference - [description]
[ ] Owner-directed change - [description]

DELAY DURATION:
Original completion: _________
New completion: _________
Delay: _____ working days

IMPACT:
[Describe impact to project]

MITIGATION:
[What you're doing to minimize delay]

This notice preserves our rights under the contract.

Signed: _________ Date: _________
```

## Look-Ahead Schedule

### 3-Week Look-Ahead Format
```
3-WEEK LOOK-AHEAD
Project: _________
Date: _________

WEEK 1 (Current)
Mon: Complete tear-off Area A
Tue: Begin deck repairs
Wed: Continue deck repairs
Thu: Begin insulation Area A
Fri: Continue insulation

Crew: 5
Materials needed: Polyiso 2.5" (100 boards)

WEEK 2
Mon-Wed: Complete insulation Area A
Thu-Fri: Begin membrane Area A

Crew: 5
Materials needed: TPO (25 rolls), Adhesive (25 gal)
Deliveries: Thursday AM

WEEK 3
Mon-Wed: Continue membrane Area A
Thu-Fri: Begin flashing Area A

Crew: 5
Materials needed: Flashing, edge metal
```

## Questions to Ask User

1. "What's the total roof area and system type?"
2. "Is this new construction or reroof?"
3. "How many crew members do you have available?"
4. "Are there any milestone dates to hit?"
5. "What's the predecessor work status?"
6. "Any weather or access constraints?"
7. "Are materials already ordered?"
