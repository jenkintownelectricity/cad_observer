# Change Order Skill

## Purpose
Document scope changes, prepare pricing for extras, and manage change order requests professionally.

## When to Use
- Additional work is requested
- Unforeseen conditions require extra work
- Scope is reduced (deductive change)
- User needs to price a potential change
- User needs to respond to a PCO request

## Change Order Process

### Step 1: Identify the Change
- What is different from original contract?
- Who requested the change?
- Is it documented? (RFI response, ASI, verbal)

### Step 2: Document
- Get change in writing before proceeding
- Photos of existing conditions
- Reference original scope

### Step 3: Price the Change
- Material quantities and costs
- Labor hours
- Equipment
- Markup (per contract)

### Step 4: Submit PCO
- Potential Change Order request
- Include all backup documentation
- Note schedule impact

### Step 5: Negotiate/Approve
- May require back-and-forth
- Document all conversations
- Get signed CO before major work

### Step 6: Track
- Update contract value
- Track approved vs pending
- Invoice when work complete

## Change Order Documentation

### PCO (Potential Change Order) Form
```
POTENTIAL CHANGE ORDER

PCO #: ________              Date: ________
Project: _____________________
To: [GC/Owner]

SUBJECT: [Brief description]

REFERENCE:
[ ] RFI #: _______ Response dated: _______
[ ] ASI #: _______ dated: _______
[ ] Verbal direction from: _______ dated: _______
[ ] Field condition discovered: _______
[ ] Other: _______

DESCRIPTION OF CHANGE:
[Detailed description of additional/changed work]

REASON FOR CHANGE:
[Why this is extra to the contract]

PROPOSED PRICE:
Labor: .......................... $________
Materials: ...................... $________
Equipment: ...................... $________
Subtotal: ....................... $________
Overhead & Profit (____%): ...... $________
TOTAL: .......................... $________

SCHEDULE IMPACT:
[ ] No impact
[ ] Add ___ working days
[ ] Concurrent with existing work

ATTACHMENTS:
[ ] Labor breakdown
[ ] Material quotes
[ ] Photos
[ ] Sketches

Authorization to proceed requested by: _______

Submitted by: _____________ Date: _______
```

## Pricing Format

### Labor Breakdown
```
LABOR BREAKDOWN - PCO #___

Task                    | Hours | Rate    | Total
------------------------|-------|---------|--------
Journeyman - Tear-off   |   16  | $85.00  | $1,360
Journeyman - Install    |   24  | $85.00  | $2,040
Foreman                 |   8   | $95.00  | $760
------------------------|-------|---------|--------
TOTAL LABOR             |   48  |         | $4,160

Burdened labor rate includes:
- Base wage
- Benefits
- Taxes
- Insurance
```

### Material Breakdown
```
MATERIAL BREAKDOWN - PCO #___

Item                    | Qty   | Unit    | Total
------------------------|-------|---------|--------
TPO membrane 60 mil     |  5 rl | $425.00 | $2,125
Insulation 2.5" polyiso | 50 bd | $32.00  | $1,600
Adhesive               |  10 gl | $85.00  | $850
Edge metal             | 200 LF | $8.50   | $1,700
------------------------|-------|---------|--------
SUBTOTAL               |        |         | $6,275
Sales Tax (___%)       |        |         | $502
TOTAL MATERIALS        |        |         | $6,777
```

### Summary Format
```
CHANGE ORDER PRICING SUMMARY

Direct Costs:
  Labor .......................... $4,160
  Materials ...................... $6,777
  Equipment ...................... $500
  --------------------------------
  Subtotal Direct Costs .......... $11,437

Markups (per contract):
  Overhead (10%) ................. $1,144
  Profit (10%) ................... $1,144
  --------------------------------
  Total Markups .................. $2,288

TOTAL CHANGE ORDER ............... $13,725
```

## Contract Markup Review

### Check Contract for:
- Overhead percentage allowed
- Profit percentage allowed
- Bond premium allowance
- Insurance allowance
- Small tools allowance
- Supervision allowance

### Typical Markup Structures
```
Type A (itemized):
- 10% overhead
- 10% profit
- 1% bond
Total: 21%

Type B (combined):
- 15% combined O&P
- Bond at cost

Type C (T&M):
- Labor at cost + 15%
- Materials at cost + 10%
- Equipment at cost + 10%
```

## Common Change Triggers

### Unforeseen Conditions
- Deck damage not visible before tear-off
- Wet insulation requiring removal
- Unknown penetrations
- Structural deficiencies
- Hazmat discovered

### Design Changes
- Architect revises details
- Owner requests upgrades
- Different membrane type
- Additional insulation

### Owner Requests
- Extended warranty
- Additional walkways
- Roof access modifications
- Equipment additions

### Coordination Issues
- Other trades not ready
- Access delays
- Work out of sequence
- Acceleration requests

## Change Order Justification Language

### For Unforeseen Conditions
"Upon removal of the existing roofing system, we discovered [condition] which was not indicated on the contract documents and could not have been reasonably anticipated. This additional work is necessary to [complete the specified work / provide a watertight installation]."

### For Design Changes
"Per [RFI response #X / ASI #X / bulletin dated X], the [detail/specification] has been revised from [original] to [revised]. This change requires additional [materials/labor/time] beyond the original contract scope."

### For Acceleration
"Per your request dated [DATE] to accelerate the completion from [original date] to [new date], the following premium time and additional resources are required."

## T&M (Time & Material) Documentation

### Daily T&M Ticket
```
TIME & MATERIAL TICKET

Date: _______        Ticket #: _______
Project: _______________________
PCO Reference: _______

LABOR:
Name          | Trade    | Start | End   | Hours
--------------|----------|-------|-------|------
              |          |       |       |
              |          |       |       |
              |          |       |       |
                    TOTAL HOURS: |       |

MATERIALS USED:
Description              | Qty  | Unit Cost | Total
------------------------|------|-----------|------
                        |      |           |
                        |      |           |

EQUIPMENT:
Description              | Hours/Days | Rate | Total
------------------------|------------|------|------
                        |            |      |

WORK PERFORMED:
_____________________________________________
_____________________________________________

Field Verification:
GC Rep: _____________ Date: _______
Contractor: _____________ Date: _______
```

## Tracking Log

```
| PCO # | Description | Submitted | Amount | Status | CO # |
|-------|-------------|-----------|--------|--------|------|
| 001 | Deck repair | 2/1 | $8,500 | Approved | 001 |
| 002 | Add walkways| 2/15 | $12,200| Pending | - |
| 003 | Wet insul | 2/20 | $3,400 | Rejected | - |
| 004 | ASI #3 chgs| 3/1 | $45,000| Negotiating| - |
```

## Tips for Change Order Success

### Do:
- Document everything with photos
- Get written authorization before work
- Price promptly (within 5-7 days)
- Reference contract terms for markup
- Include schedule impact
- Keep detailed T&M records

### Don't:
- Start extra work without documentation
- Accept verbal authorization for big changes
- Delay pricing (memories fade, leverage decreases)
- Pad estimates (damages credibility)
- Forget bond and insurance costs

## Questions to Ask User

1. "What work is being changed or added?"
2. "Who authorized this change?" (Get it in writing)
3. "What's the reference?" (RFI, ASI, verbal direction)
4. "What does your contract say about markup?"
5. "Is work already started?" (T&M or lump sum)
6. "What's the schedule impact?"
