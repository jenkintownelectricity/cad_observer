# Roofing Project Manager Skills for Claude

A comprehensive set of Claude skills for commercial roofing project management.

## Skills Included

| Skill | Purpose |
|-------|---------|
| **estimating** | Takeoffs, material calculations, labor estimates |
| **bid-prep** | Proposal writing, scope letters, pricing |
| **spec-interpreter** | Division 07 spec parsing, requirements extraction |
| **submittals** | Product data, shop drawings, certifications |
| **rfi-writer** | Request for Information drafting and tracking |
| **change-orders** | Extra work pricing, PCO documentation |
| **scheduling** | Project scheduling, crew planning, material coordination |
| **safety** | JHAs, toolbox talks, fall protection plans |
| **quality-control** | Inspection checklists, punch lists |
| **daily-reports** | Progress documentation, weather tracking |
| **closeout** | Warranties, as-builts, O&M manuals |
| **contract-review** | Contract terms, risk identification |

## Installation

### For Claude Projects (claude.ai)
1. Create a new Project
2. Upload the entire `roofing-pm-skills` folder to Project Knowledge
3. Add this to your Project Instructions:

```
You are a commercial roofing project management assistant with access to specialized skills for:
- Estimating and takeoffs
- Bid preparation and pricing
- Specification interpretation (Division 07)
- Submittals and shop drawings
- RFI writing
- Change order management
- Scheduling and crew planning
- Safety documentation
- Quality control
- Daily reporting
- Project closeout
- Contract review

When the user asks for help with any of these topics, reference the appropriate SKILL.md file in your knowledge base to provide industry-standard guidance and templates.

Use correct construction terminology. Reference spec sections (07 XX 00) when relevant. Ask clarifying questions before making assumptions.
```

### For Claude Code
1. Clone or copy to your project
2. Claude Code will read the SKILL.md files for context

## Quick Reference

### Division 07 Spec Sections
- 07 10 00 - Dampproofing and Waterproofing
- 07 20 00 - Thermal Protection (Insulation)
- 07 27 00 - Air Barriers
- 07 50 00 - Membrane Roofing
- 07 52 00 - Modified Bituminous Membrane
- 07 54 00 - Thermoplastic Membrane (TPO/PVC)
- 07 60 00 - Flashing and Sheet Metal
- 07 62 00 - Sheet Metal Flashing and Trim
- 07 70 00 - Roof Specialties
- 07 92 00 - Joint Sealants

### Common Membrane Systems
- **TPO** - Thermoplastic polyolefin (heat welded)
- **EPDM** - Ethylene propylene diene monomer (adhered/mechanical)
- **PVC** - Polyvinyl chloride (heat welded)
- **Mod-Bit** - Modified bitumen (torch/cold/self-adhered)
- **BUR** - Built-up roofing (hot mopped)

### Standard Production Rates (5-man crew)
| Task | SF/Day |
|------|--------|
| TPO adhered | 4,000 |
| TPO mechanical | 5,000 |
| Mod-bit torch | 3,000 |
| Insulation (1 layer) | 8,000 |
| Tear-off (single ply) | 5,000 |

## Usage Examples

### Estimating
"Help me calculate materials for a 50,000 SF TPO roof with 20 drains and 1,500 LF of parapet."

### Bid Prep
"Write a scope letter for a reroof project - 35,000 SF, TPO over existing BUR."

### RFI
"The drawings show TPO but the spec calls out mod-bit. Help me write an RFI."

### Change Order
"We found wet insulation during tear-off. Help me price the extra work."

### Safety
"Create a JHA for torch-applied roofing."

### Contract Review
"Review this subcontract and flag any concerning clauses."

## File Structure
```
roofing-pm-skills/
├── README.md
├── estimating/
│   └── SKILL.md
├── bid-prep/
│   └── SKILL.md
├── spec-interpreter/
│   └── SKILL.md
├── submittals/
│   └── SKILL.md
├── rfi-writer/
│   └── SKILL.md
├── change-orders/
│   └── SKILL.md
├── scheduling/
│   └── SKILL.md
├── safety/
│   └── SKILL.md
├── quality-control/
│   └── SKILL.md
├── daily-reports/
│   └── SKILL.md
├── closeout/
│   └── SKILL.md
└── contract-review/
    └── SKILL.md
```

## Contributing
These skills are based on industry experience. Contributions and corrections welcome.

## License
MIT - Use freely for your roofing business.
