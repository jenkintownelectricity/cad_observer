# Roofing Estimating & Takeoff Skill

## Purpose
Assist with roof area takeoffs, material calculations, and labor estimates for commercial roofing projects.

## When to Use
- User uploads architectural drawings or PDFs
- User asks to calculate roof area, material quantities, or labor hours
- User needs to count drains, penetrations, curbs, or other roof features
- User asks for a material list or quantity takeoff

## Inputs Needed
1. **Drawings** - Roof plan PDF, CAD export, or screenshot
2. **Spec section** - 07 50 00, 07 52 00, etc. (or user describes system)
3. **Scale** - Drawing scale (1/8" = 1'-0", etc.)
4. **System type** - TPO, EPDM, mod-bit, BUR, etc.

## Process

### Step 1: Identify Roof Areas
Ask user to confirm:
- Total roof square footage (or measure from drawing)
- Number of separate roof areas/levels
- Slope conditions (flat, tapered, pitched)

### Step 2: Count Features
From drawings, identify and count:
- **Drains**: Roof drains, overflow drains, scuppers
- **Penetrations**: Pipes, vents, conduits
- **Curbs**: RTU curbs, skylight curbs, equipment curbs
- **Hatches**: Roof hatches, smoke vents
- **Edges**: Linear feet of perimeter edge, parapet, coping
- **Expansion joints**: Linear feet
- **Walls**: Linear feet of wall termination/base flashing

### Step 3: Calculate Materials

#### Membrane (add 10% waste)
```
Field membrane SF = Roof area × 1.10
Rolls needed = Field SF ÷ Roll coverage
```

#### Flashing (add 15% waste)
```
Base flashing LF = Wall terminations + curb perimeters
Edge metal LF = Perimeter + 10%
Coping LF = Parapet length + 10%
```

#### Insulation
```
Polyiso boards = Roof SF ÷ Board SF × Layers
Cover board = Roof SF ÷ Board SF
```

#### Accessories
```
Fasteners = Based on attachment pattern (typically 1 per SF for mechanically attached)
Adhesive = Based on manufacturer coverage rates
Drain assemblies = Count from drawings
Pipe boots = Count penetrations by size
Curb adapters = Count curbs
```

## Material Coverage Rates

### Membrane
| Product | Roll Size | Coverage |
|---------|-----------|----------|
| TPO 60 mil | 10' × 100' | 1,000 SF |
| EPDM 60 mil | 10' × 100' | 1,000 SF |
| Mod-bit base | 3' × 33' | ~100 SF |
| Mod-bit cap | 3' × 33' | ~100 SF |

### Insulation
| Product | Size | Coverage |
|---------|------|----------|
| Polyiso 4' × 8' | 32 SF | 32 SF |
| Polyiso 4' × 4' | 16 SF | 16 SF |
| Cover board | 4' × 8' | 32 SF |

### Adhesive/Bonding
| Product | Coverage |
|---------|----------|
| Low-rise adhesive | 60-80 SF/gal |
| Bonding adhesive | 50-60 SF/gal |
| EPDM splice adhesive | 150-200 LF/gal |

### Fasteners
| Pattern | Fasteners/SF |
|---------|--------------|
| Standard | 1.0 |
| High wind | 1.5-2.0 |
| FM 1-90 | ~1.0 |
| FM 1-120 | ~1.3 |

## Labor Production Rates

### Membrane Installation
| System | SF/Man-Hour |
|--------|-------------|
| TPO fully adhered | 100-150 |
| TPO mechanically attached | 150-200 |
| EPDM fully adhered | 100-150 |
| Mod-bit 2-ply torch | 75-100 |
| Mod-bit 2-ply cold | 60-80 |
| BUR 4-ply | 50-75 |

### Flashing
| Item | LF/Man-Hour |
|------|-------------|
| Base flashing | 15-20 |
| Edge metal | 20-30 |
| Coping | 15-20 |
| Counter flashing | 10-15 |

### Accessories
| Item | Units/Man-Hour |
|------|----------------|
| Roof drains | 2-3 |
| Pipe boots (small) | 4-6 |
| Curb flashing | 1-2 |
| Expansion joint | 10-15 LF |

### Insulation
| Type | SF/Man-Hour |
|------|-------------|
| Polyiso (1 layer) | 200-300 |
| Polyiso (2 layers) | 150-200 |
| Cover board | 200-250 |
| Tapered system | 100-150 |

## Output Format

```
QUANTITY TAKEOFF
Project: [Name]
Date: [Date]
Prepared by: [Name]

ROOF AREAS
-----------------------------------------
Area 1: [Name]          [XX,XXX] SF
Area 2: [Name]          [XX,XXX] SF
-----------------------------------------
TOTAL ROOF AREA:        [XX,XXX] SF

MEMBRANE
-----------------------------------------
TPO 60 mil (10' rolls)      [XX] rolls
Seam tape                   [XX] rolls
Bonding adhesive            [XX] gal

INSULATION
-----------------------------------------
Polyiso 2.5" (R-15)         [XXX] boards
Polyiso 1.5" (R-9)          [XXX] boards
Cover board 1/2"            [XXX] boards

FLASHING & EDGE METAL
-----------------------------------------
Base flashing               [XXX] LF
Edge metal                  [XXX] LF
Coping                      [XXX] LF
Counter flashing            [XXX] LF

ACCESSORIES
-----------------------------------------
Roof drains (4")            [XX] ea
Overflow drains             [XX] ea
Pipe boots 1-3"             [XX] ea
Pipe boots 4-6"             [XX] ea
RTU curb adapters           [XX] ea

FASTENERS & ADHESIVES
-----------------------------------------
Fasteners (2.5")            [X,XXX] ea
Plates                      [X,XXX] ea
Bonding adhesive            [XXX] gal

LABOR ESTIMATE
-----------------------------------------
Membrane installation       [XXX] MH
Insulation                  [XXX] MH
Flashing                    [XXX] MH
Accessories                 [XXX] MH
-----------------------------------------
TOTAL LABOR:                [XXX] MH
Crew size: [X] / Duration: [XX] days
```

## Questions to Ask User

1. "What roofing system is specified?" (TPO, EPDM, mod-bit, etc.)
2. "What's the attachment method?" (Fully adhered, mechanically attached, ballasted)
3. "What insulation R-value is required?"
4. "Is there existing roofing to remove?" (Tear-off vs. recover)
5. "Any tapered insulation for drainage?"
6. "What's the wind uplift requirement?" (FM 1-90, 1-120, etc.)

## Common Mistakes to Avoid

- Forgetting waste factors (10% membrane, 15% flashing)
- Not counting both sides of curbs for flashing
- Missing overflow drains (code requirement)
- Underestimating edge metal at direction changes
- Forgetting penetration boots for conduits
- Not accounting for field seams in membrane count
