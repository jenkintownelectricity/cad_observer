# AutoCAD Reference for Shop Drawing Drafters

## Quick Command Reference

### Essential Drawing Commands
| Command | Alias | Use |
|---------|-------|-----|
| LINE | L | Basic line drawing |
| PLINE | PL | Polyline (continuous, closed shapes) |
| RECTANGLE | REC | Quick rectangles |
| CIRCLE | C | Circles |
| ARC | A | Arcs |
| HATCH | H | Fill patterns |
| OFFSET | O | Parallel copies |
| TRIM | TR | Cut lines at intersections |
| EXTEND | EX | Extend to boundary |
| FILLET | F | Round corners (set R=0 for clean corners) |
| CHAMFER | CHA | Angled corners |

### Editing Commands
| Command | Alias | Use |
|---------|-------|-----|
| MOVE | M | Move objects |
| COPY | CO | Copy objects |
| ROTATE | RO | Rotate objects |
| SCALE | SC | Scale objects |
| MIRROR | MI | Mirror objects |
| ARRAY | AR | Rectangular/polar patterns |
| STRETCH | S | Stretch portions |
| EXPLODE | X | Break apart blocks/plines |
| PEDIT | PE | Edit polylines |
| JOIN | J | Join lines into polyline |

### Annotation Commands
| Command | Alias | Use |
|---------|-------|-----|
| DIMLINEAR | DLI | Linear dimensions |
| DIMALIGNED | DAL | Aligned dimensions |
| DIMANGULAR | DAN | Angular dimensions |
| DIMRADIUS | DRA | Radius dimensions |
| DIMDIAMETER | DDI | Diameter dimensions |
| LEADER | LE | Leader with text |
| MLEADER | MLD | Multi-leader (recommended) |
| TEXT | DT | Single line text |
| MTEXT | MT | Multi-line text |

### Layer Commands
| Command | Alias | Use |
|---------|-------|-----|
| LAYER | LA | Layer properties manager |
| LAYMCH | - | Match object to layer |
| LAYCUR | - | Set current layer from object |
| LAYISO | - | Isolate selected layers |
| LAYUNISO | - | Restore isolated layers |
| LAYFRZ | - | Freeze selected layer |
| LAYTHW | - | Thaw all layers |
| LAYOFF | - | Turn off layer |
| LAYON | - | Turn on all layers |

### Block Commands
| Command | Alias | Use |
|---------|-------|-----|
| BLOCK | B | Create block |
| INSERT | I | Insert block |
| WBLOCK | W | Write block to file |
| BEDIT | BE | Edit block definition |
| REFEDIT | - | Edit xref/block in place |
| BATTMAN | - | Block attribute manager |

### View Commands
| Command | Alias | Use |
|---------|-------|-----|
| ZOOM | Z | Zoom (E=extents, A=all, W=window) |
| PAN | P | Pan view |
| REGEN | RE | Regenerate display |
| REGENALL | REA | Regenerate all viewports |

## Productivity Shortcuts

### Quick Selection
```
Double-click: Edit text/block/hatch
Ctrl+A: Select all
Ctrl+Shift+A: Toggle groups
Right-click: Context menu

Selection modes:
- Window (left to right): Objects fully inside
- Crossing (right to left): Objects touching
- Fence: Objects crossing a line
```

### Quick Properties
```
Ctrl+1: Properties palette
Ctrl+Shift+P: Quick properties
Match properties: MA (then select source, then targets)
```

### Osnap Settings (F3 to toggle)
```
Essential osnaps for details:
- Endpoint
- Midpoint
- Intersection
- Perpendicular
- Nearest

Temporary override: Hold Shift + right-click
```

## Detail Drawing Workflow

### Starting a New Detail
```
1. Set appropriate scale (3/4" = 1'-0" typical)
2. Draw in full scale (real dimensions)
3. Create layers as needed
4. Draw from bottom up (deck first)
5. Add dimensions
6. Add notes and leaders
7. Add detail title and scale
```

### Layer Setup Script
```lisp
; Run this to create standard roofing layers
(command "-layer" 
  "m" "ROOF-MEMB" "c" "4" "" 
  "m" "ROOF-FLASH" "c" "2" "" 
  "m" "ROOF-DRAIN" "c" "5" "" 
  "m" "ROOF-PENE" "c" "6" "" 
  "m" "ROOF-CURB" "c" "3" "" 
  "m" "ROOF-INSUL" "c" "8" "" 
  "m" "ROOF-DIMS" "c" "7" "" 
  "m" "ROOF-NOTE" "c" "1" "" 
  "m" "ROOF-ANNO" "c" "1" "" 
  "m" "ROOF-SYMB" "c" "7" "" 
  "m" "ROOF-HATCH" "c" "8" "" 
  "")
```

### Standard Hatch Patterns
| Material | Pattern | Scale | Notes |
|----------|---------|-------|-------|
| Concrete | AR-CONC | 1 | Structural concrete |
| Insulation | INSUL | 1 | Rigid insulation |
| Earth/fill | EARTH | 1 | Below grade |
| Metal | STEEL | 1 | Sheet metal sections |
| Membrane | SOLID | - | Use gray color |
| Wood | AR-HBONE | 1 | Blocking/nailers |
| Masonry | AR-BRSTD | 1 | CMU walls |

## Common Detail Components

### Cant Strip (45° Triangle)
```
Command sequence:
PLINE
0,0
4,0
0,4
C (close)

Or use POLYGON with 3 sides and rotate 45°
```

### Metal Flashing Profile
```
Typical edge metal:
PLINE
0,0
4,0 (flange width)
4,-1.5 (down to face)
4.5,-1.5 (drip)
4.5,-2 (drip return)
4,-2
4,-6 (face height)
0,-6 (back)
C (close)
```

### Reglet Detail
```
PLINE
0,0
1,0 (depth into wall)
1,-0.5 (reglet depth)
0,-0.5
0,-0.75 (lip)
-0.5,-0.75 (flashing pocket)
```

## Dimension Styles

### Creating Roofing Dimension Style
```
DIMSTYLE settings:
- Text height: 3/32" (0.09375)
- Arrow size: 3/32"
- Extension line offset: 1/16"
- Dimension line spacing: 3/8"
- Units: Architectural
- Precision: 1/16" or 1/8"
- Tolerance: None
```

### Dimension Tips
- Use DIMLINEAR for horizontal/vertical
- Use DIMALIGNED for angled surfaces
- Use DIMCONTINUE for string dimensions
- Use DIMBASELINE for stacked from single point

## Text Styles

### Standard Text Styles
```
Style: NOTES
- Font: Arial or Simplex
- Height: 0 (set at placement)
- Width factor: 1.0

Style: TITLES
- Font: Arial Bold
- Height: 0
- Width factor: 1.0

Style: DIMS
- Font: Arial
- Height: 0.09375 (3/32")
- Width factor: 1.0
```

## Block Library Essentials

### Plan Symbols
```
DRAIN-4     4" roof drain symbol (plan)
DRAIN-6     6" roof drain symbol (plan)
DRAIN-OF    Overflow drain symbol
PENE-SM     Small penetration (1"-3")
PENE-MD     Medium penetration (4"-6")
PENE-LG     Large penetration (7"+)
CURB        Equipment curb symbol
HATCH       Roof hatch symbol
SLOPE-ARW   Slope direction arrow
NORTH       North arrow
SECTION     Section cut symbol
DETAIL      Detail reference bubble
```

### Creating a Drain Symbol Block
```
1. Draw circle (4" diameter)
2. Draw inner circle (3" diameter) 
3. Add crosshairs
4. BLOCK command
5. Name: DRAIN-4
6. Pick insertion point: center
7. Select objects
8. Save as block
```

## Xref Management

### Xref Best Practices
```
- Attach architectural plans as xref
- Use OVERLAY (not ATTACH) to prevent nesting
- Create separate xref for grids only
- Bind xrefs before final submission
- Use relative paths when possible
```

### Xref Commands
```
XREF or XR    - Xref manager
XATTACH       - Attach xref
XBIND         - Bind xref elements
XCLIP         - Clip xref boundary
XOPEN         - Open xref for editing
```

## Plotting/Publishing

### Plot Settings for Details
```
Paper size: ARCH D (24×36) typical
Plot scale: 1:1 (drawings at paper size)
Plot style: monochrome.ctb or company standard
Plot area: Layout or Window
```

### PDF Export
```
EXPORTPDF command
Or PLOT with DWG to PDF.pc3

Settings:
- Vector quality
- Include layer information
- Password protect if needed
```

## Troubleshooting

### Common Issues

**Lines not connecting?**
- Check OSNAP settings
- Use FILLET with R=0 to clean corners
- PEDIT > Join to connect

**Dimensions wrong scale?**
- Check DIMSCALE
- Check annotative settings
- Verify you're drawing at 1:1

**Hatches not working?**
- Boundary must be closed
- Check for gaps with ZOOM
- Use "Pick Points" not "Select Objects"

**Xref not updating?**
- XREF > Reload
- Check file path
- REGEN after reload

**Text too small/large?**
- Check text style height
- Check viewport scale
- Use annotative text

## Keyboard Shortcuts to Memorize

```
ESC       - Cancel command
ENTER     - Repeat last command
SPACE     - Same as ENTER
F3        - Toggle OSNAP
F7        - Toggle GRID
F8        - Toggle ORTHO
F9        - Toggle SNAP
F10       - Toggle POLAR
F11       - Toggle OTRACK
Ctrl+Z    - Undo
Ctrl+Y    - Redo
Ctrl+S    - Save
Ctrl+C    - Copy to clipboard
Ctrl+V    - Paste
Ctrl+Shift+V - Paste as block
```

## File Organization

### Project Folder Structure
```
Project-2024-001/
├── 01-Contract-Docs/
│   ├── Drawings/
│   └── Specs/
├── 02-Shop-Drawings/
│   ├── Working/
│   ├── Submitted/
│   └── Approved/
├── 03-Xrefs/
│   ├── Arch-Plans/
│   └── Grids/
├── 04-Blocks/
├── 05-PDFs/
│   ├── Submittals/
│   └── Approved/
└── 06-Backup/
```

### File Naming
```
[Project#]-SD-[Sheet#]-[Desc]-[Rev].dwg

Examples:
2024-001-SD-701-RoofPlan-R0.dwg
2024-001-SD-702-Details-R0.dwg
2024-001-SD-702-Details-R1.dwg (after revision)
```

## Quality Check Before Submitting

```
[ ] Purge unused items (PURGE command)
[ ] Audit drawing (AUDIT command)
[ ] Check all dimensions
[ ] Verify text is readable
[ ] Check xref paths
[ ] Verify scale bars
[ ] Check layer 0 for stray objects
[ ] Spell check notes
[ ] Verify north arrow direction
[ ] Check sheet number sequence
[ ] Export to PDF and review
```
