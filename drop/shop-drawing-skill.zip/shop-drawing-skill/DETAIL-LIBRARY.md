# Standard Detail Library - Division 07

## Detail Index

### Base Flashing Details (FL Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| FL-01 | Base flashing at masonry wall | CMU or brick parapet |
| FL-02 | Base flashing at metal stud wall | Steel stud backup |
| FL-03 | Base flashing at concrete wall | Cast-in-place or precast |
| FL-04 | Base flashing at equipment curb | Standard curb flashing |
| FL-05 | Base flashing at pitch pan | Irregular penetrations |
| FL-06 | Base flashing at expansion joint | Building E.J. |

### Edge Metal Details (EM Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| EM-01 | Gravel stop | Standard roof edge |
| EM-02 | Fascia with drip | Extended fascia required |
| EM-03 | Coping at parapet | Low parapet with coping |
| EM-04 | Through-wall coping | Full parapet coverage |
| EM-05 | Edge at gutter | Integral gutter condition |
| EM-06 | Expansion joint in edge | Long runs (>40') |

### Drain Details (DR Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| DR-01 | Standard roof drain | Primary drain |
| DR-02 | Overflow drain | Secondary/overflow |
| DR-03 | Retrofit drain | Over existing drain |
| DR-04 | Sump pan drain | Raised sump required |
| DR-05 | Scupper | Through-wall drainage |
| DR-06 | Scupper with downspout | Scupper to leader |

### Penetration Details (PN Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| PN-01 | Pipe boot (small) | Pipes 1"-3" |
| PN-02 | Pipe boot (large) | Pipes 4"-8" |
| PN-03 | Split boot | Existing pipe, no access |
| PN-04 | Pitch pan | Irregular shapes |
| PN-05 | Conduit penetration | Electrical conduit |
| PN-06 | Gas vent (B-vent) | With clearance requirements |

### Curb Details (CB Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| CB-01 | Standard equipment curb | RTU, exhaust fan |
| CB-02 | Skylight curb | Skylight installation |
| CB-03 | Roof hatch curb | Access hatch |
| CB-04 | Smoke vent curb | Smoke/heat vent |
| CB-05 | Raised curb at low slope | Additional height needed |
| CB-06 | Curb at re-roof | Over existing curb |

### Transition Details (TR Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| TR-01 | TPO to mod-bit | System transition |
| TR-02 | New to existing | Tie-in to existing roof |
| TR-03 | Roof to plaza deck | Horizontal transition |
| TR-04 | Membrane to metal roof | System change |
| TR-05 | Low slope to steep slope | Slope change |

### Miscellaneous Details (MS Series)
| Detail # | Description | Use When |
|----------|-------------|----------|
| MS-01 | Walkway pads | Maintenance paths |
| MS-02 | Equipment support | Pipe supports, conduit |
| MS-03 | Lightning protection | Conductor attachment |
| MS-04 | Fall protection anchor | Safety anchor points |
| MS-05 | Area divider | Large roof separation |

---

## Detail Descriptions

### FL-01: Base Flashing at Masonry Wall

**Application:** CMU block or brick parapet walls

**Components (bottom to top):**
1. Metal deck or concrete substrate
2. Vapor retarder (verify spec requirement)
3. Polyiso insulation - [thickness per spec]
4. Cover board - [type per spec]
5. Fully adhered roof membrane
6. Preformed 4"×4" cant strip at wall intersection
7. Base flashing membrane min. 8" up wall
8. Termination bar at 8" height, fastened 6" O.C.
9. Sealant bead at top of termination bar
10. Reglet counter flashing by mason (or surface-mounted)

**Critical Notes:**
- Flash minimum 8" above roof surface
- Prime all metal before membrane contact
- Reinforce inside corners with additional ply
- Reinforce outside corners with additional ply
- Seal all fastener penetrations
- Counter flashing overlap minimum 4"

**Coordination:**
- Verify reglet is installed by mason before roofing
- If no reglet, use surface-mounted counter flashing

---

### FL-04: Base Flashing at Equipment Curb

**Application:** RTU curbs, exhaust fan curbs, skylight curbs

**Components:**
1. Wood blocking at curb perimeter (P.T. lumber)
2. Cant strip at curb/deck intersection
3. Field membrane over cant, up face of curb
4. Base flashing wrapped continuously around curb
5. Termination at top of curb or under equipment flange
6. Metal counterflashing cap (if exposed)

**Critical Dimensions:**
- Curb height: 8" minimum above roof surface
- Curb height: 12" minimum if within 10' of drain
- Flashing up full height of curb
- Provide min. 4" horizontal flange at top

**Critical Notes:**
- Flash all four sides continuously
- Reinforce all corners (inside and outside)
- Coordinate curb dimensions with equipment
- Verify curb dimensions before fabrication
- Provide cant strip at base of curb on all sides

---

### EM-01: Gravel Stop Edge Metal

**Application:** Standard roof edge termination

**Components:**
1. 2× wood nailer at roof edge
2. Field membrane over nailer
3. Edge metal flange (min. 4") under membrane
4. Vertical face (height per schedule)
5. Hem at bottom edge
6. Sealant at joints

**Critical Dimensions:**
- Flange: 4" minimum
- Face: per schedule (typically 4"-6")
- Gauge: per spec (typically 24 ga.)
- Joints: 10'-0" maximum spacing
- Expansion joints: per design/manufacturer

**Critical Notes:**
- Set in bed of sealant
- Seal all joints
- Provide end dams at terminations
- Prime before membrane application

---

### EM-03: Coping at Parapet

**Application:** Low parapet with metal coping

**Components:**
1. Parapet wall construction
2. Base flashing up parapet face
3. Wood nailer at top of parapet
4. Coping with continuous cleat
5. Sealant at wall junction

**Critical Dimensions:**
- Coping width: Cover wall + 2" overhang each side
- Gauge: per spec (typically 22-24 ga.)
- Cleat: continuous both sides
- Joints: with splice plates, sealed

**Critical Notes:**
- Provide positive slope for drainage
- Minimum 4" overlap at base flashing
- Seal all joints and end dams
- Anchor clips per wind design

---

### DR-01: Standard Roof Drain

**Application:** Primary roof drainage

**Components:**
1. Cast iron drain body set in mastic
2. Under-deck clamp (for metal deck)
3. Roof membrane sandwiched in clamping ring
4. Membrane flashing around drain perimeter
5. Tapered insulation sloping to drain
6. Drain dome/strainer

**Critical Dimensions:**
- Drain size: per schedule (typically 4")
- Sump: 1" minimum below membrane surface
- Flashing: 12" minimum from drain edge
- Tapered slope: 1/4" per foot minimum

**Critical Notes:**
- Set drain at lowest point
- Verify leader connection before covering
- Test drain flow before final installation
- Install overflow drain per code (within 10')

---

### DR-05: Scupper

**Application:** Through-wall drainage

**Components:**
1. Sheet metal scupper box
2. Membrane lining in scupper
3. Flashing around scupper opening
4. Conductor head or downspout connection
5. Overflow weir (if primary fails)

**Critical Dimensions:**
- Size: per hydraulic calculation
- Typical: 6"×6" minimum
- Set: at roof surface level for primary
- Set: 2" above roof for overflow

**Critical Notes:**
- Slope scupper to exterior
- Seal all joints
- Provide conductor head if connecting to downspout
- Flash full perimeter

---

### PN-01: Pipe Boot (Small)

**Application:** Plumbing vents, conduits 1"-3"

**Components:**
1. Pipe through roof deck
2. Field membrane around penetration
3. Pipe boot (size to match pipe)
4. Boot set in mastic bed
5. Sealant at pipe/boot junction
6. Stainless steel clamp band

**Critical Dimensions:**
- Boot: sized to pipe O.D.
- Height: 8" minimum above roof
- Boot flange: 9" typical

**Critical Notes:**
- Verify pipe size before ordering
- Prime metal before contact
- Allow for pipe movement
- Check for proper seal at pipe

---

### PN-04: Pitch Pan

**Application:** Irregular penetrations (angles, multiple pipes, structural)

**Components:**
1. Penetration through deck
2. Sheet metal pan welded to deck
3. Membrane under pan flange
4. Membrane flashing around pan
5. Pourable sealer filling pan
6. Grease/pour coat at top

**Critical Dimensions:**
- Pan: 2" minimum clearance around penetration
- Pan height: 4" minimum
- Fill: to within 1" of top

**Critical Notes:**
- Requires periodic maintenance
- Fill with approved pourable sealer
- Top with compatible grease
- Consider curb alternative for large penetrations

---

### CB-01: Standard Equipment Curb

**Application:** Rooftop units, exhaust fans

**Components:**
1. Prefabricated or site-built curb
2. Cant strip at base
3. Base flashing membrane
4. Counter flashing at equipment
5. Vibration isolation (if required)

**Critical Dimensions:**
- Width/Length: per equipment
- Height: 8" minimum (12" near drains)
- Nailer: around full perimeter

**Critical Notes:**
- Verify equipment dimensions before fabrication
- Coordinate with mechanical contractor
- Ensure proper support for equipment weight
- Flash before equipment installation

---

### TR-02: New to Existing Roof Tie-In

**Application:** Phased construction, additions, repairs

**Components:**
1. Existing roof membrane
2. Cut back existing to sound material
3. Prime existing membrane
4. Transition strip
5. New membrane lapped over transition
6. Additional ply at transition

**Critical Dimensions:**
- New over existing: 6" minimum overlap
- Transition strip: 12" wide typical
- Cut back: as needed to sound membrane

**Critical Notes:**
- Verify existing membrane compatibility
- Clean and prime existing surface
- Provide positive seal at transition
- Document existing conditions

---

## Detail Notes Library

### Note Set A - General
```
1. ALL WORK PER CONTRACT DOCUMENTS.
2. VERIFY ALL DIMENSIONS IN FIELD.
3. REFER TO SPECIFICATIONS FOR MATERIAL REQUIREMENTS.
4. COORDINATE WITH OTHER TRADES.
```

### Note Set B - Membrane
```
1. MEMBRANE: [MFR] [PRODUCT], [THICKNESS], [COLOR].
2. FULLY ADHERE MEMBRANE PER MANUFACTURER.
3. HEAT WELD ALL SEAMS AND LAPS.
4. MINIMUM 2.5" SEAM WIDTH.
```

### Note Set C - Flashing
```
1. FLASH MINIMUM 8" ABOVE FINISHED ROOF.
2. PRIME ALL METAL BEFORE MEMBRANE APPLICATION.
3. REINFORCE ALL CORNERS.
4. SEAL ALL TERMINATIONS.
```

### Note Set D - Insulation
```
1. INSULATION: [MFR] [PRODUCT], R-[VALUE].
2. STAGGER ALL JOINTS BETWEEN LAYERS.
3. FIT TIGHT TO WALLS AND PENETRATIONS.
4. MECHANICALLY FASTEN PER FM REQUIREMENTS.
```

### Note Set E - Sheet Metal
```
1. EDGE METAL: [GAUGE] [MATERIAL] WITH [FINISH].
2. JOINTS MAXIMUM 10'-0" O.C.
3. PROVIDE EXPANSION JOINTS PER MANUFACTURER.
4. SEAL ALL JOINTS WITH COMPATIBLE SEALANT.
```

### Note Set F - Drains
```
1. SET DRAIN BOWL IN FULL BED OF MASTIC.
2. VERIFY LEADER CONNECTION BEFORE COVERING.
3. PROVIDE OVERFLOW DRAIN WITHIN 10'-0".
4. INSTALL DOME STRAINER AT COMPLETION.
```
