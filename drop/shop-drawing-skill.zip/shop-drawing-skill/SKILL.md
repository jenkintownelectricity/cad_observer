# Shop Drawing Drafter Skill

## Purpose
Create professional roofing and waterproofing shop drawings for Division 07 work, including roof plans, details, and schedules.

## When to Use
- User needs to create shop drawings for a project
- User asks about detail development
- User needs layer standards or CAD conventions
- User asks about flashing details or assemblies
- User needs to interpret architect's details for fabrication

## What Shop Drawings Include

### For Roofing (07 50 00 - 07 58 00)
1. **Roof Plan** - Overall layout showing:
   - Membrane field and seam layout
   - Drain locations with sizes
   - Penetration locations
   - Equipment curb locations
   - Edge conditions
   - Slope directions/crickets
   - Match lines for large roofs

2. **Detail Drawings** - Enlarged views of:
   - Base flashing at walls
   - Base flashing at curbs
   - Edge metal conditions
   - Drain assemblies
   - Penetration flashing
   - Expansion joints
   - Transitions between systems

3. **Schedules** - Tabular data:
   - Drain schedule
   - Penetration schedule
   - Curb schedule
   - Material schedule

### For Waterproofing (07 10 00 - 07 18 00)
1. **Waterproofing Plan** - Layout showing:
   - Membrane extents
   - Drain locations
   - Transition locations
   - Protection board extents

2. **Detail Drawings**:
   - Wall terminations
   - Slab penetrations
   - Expansion joints
   - Waterstops
   - Drain connections
   - Plaza deck assemblies

### For Sheet Metal (07 62 00)
1. **Sheet Metal Drawings**:
   - Edge metal profiles
   - Coping profiles
   - Counter flashing profiles
   - Fabrication dimensions
   - Joint locations
   - Expansion joint spacing

## CAD Layer Standards

### Recommended Layer Naming Convention
```
[DISCIPLINE]-[COMPONENT]-[MODIFIER]

Examples:
ROOF-MEMB          Membrane field
ROOF-MEMB-SEAM     Membrane seams
ROOF-FLASH         Flashing
ROOF-FLASH-BASE    Base flashing
ROOF-FLASH-EDGE    Edge metal
ROOF-DRAIN         Drains
ROOF-PENE          Penetrations
ROOF-CURB          Equipment curbs
ROOF-INSUL         Insulation
ROOF-SLOPE         Slope arrows
ROOF-DIMS          Dimensions
ROOF-NOTE          Notes and leaders
ROOF-ANNO          Annotations/tags
ROOF-SYMB          Symbols
ROOF-GRID          Grid lines (xref)
ROOF-BLDG          Building outline (xref)

WP-MEMB            Waterproofing membrane
WP-FLASH           Waterproofing flashing
WP-PROT            Protection board
WP-DRAIN           Drainage mat/board

SM-EDGE            Sheet metal edge
SM-COPE            Coping
SM-CNTR            Counter flashing
SM-GRVL            Gravel stop
SM-DIMS            Sheet metal dimensions
```

### Layer Colors (Suggested)
| Layer | Color | Purpose |
|-------|-------|---------|
| ROOF-MEMB | Cyan (4) | Field membrane |
| ROOF-FLASH | Yellow (2) | Flashing |
| ROOF-DRAIN | Blue (5) | Drains |
| ROOF-PENE | Magenta (6) | Penetrations |
| ROOF-CURB | Green (3) | Curbs |
| ROOF-DIMS | White (7) | Dimensions |
| ROOF-NOTE | Red (1) | Notes |
| ROOF-ANNO | Red (1) | Annotations |

### Lineweights
| Element | Lineweight | Layer |
|---------|------------|-------|
| Object lines | 0.35mm | Various |
| Dimension lines | 0.18mm | DIMS |
| Leader lines | 0.18mm | NOTE |
| Hidden lines | 0.18mm | -HIDDEN |
| Center lines | 0.18mm | -CNTR |
| Border | 0.50mm | BORDER |

## Drawing Standards

### Scale Standards
| Drawing Type | Scale |
|--------------|-------|
| Roof plan (small) | 1/8" = 1'-0" |
| Roof plan (large) | 1/16" = 1'-0" |
| Enlarged plans | 1/4" = 1'-0" |
| Details | 3/4" = 1'-0" |
| Details | 1" = 1'-0" |
| Details | 1-1/2" = 1'-0" |
| Details | 3" = 1'-0" |
| Full size profiles | FULL |

### Text Standards
| Element | Height (plotted) | Style |
|---------|------------------|-------|
| Room names/titles | 3/16" | Bold |
| Dimensions | 3/32" | Standard |
| Notes | 3/32" | Standard |
| Detail titles | 1/4" | Bold |
| Sheet title | 3/8" | Bold |

### Dimension Standards
- Dimension to face of materials
- String dimensions where possible
- Overall dimension on outside
- Fractional inches for details
- Feet-inches for plans
- Note: "U.N.O." for "Unless Noted Otherwise"

## Standard Roofing Details

### Base Flashing at Wall (Parapet)
```
COMPONENTS (bottom to top):
1. Structural deck
2. Vapor retarder (if required)
3. Insulation layer(s)
4. Cover board
5. Roof membrane (extend up wall min. 8")
6. Cant strip at wall/deck intersection
7. Base flashing membrane
8. Termination bar at top
9. Sealant above termination bar
10. Counter flashing (by others or by roofer)

CRITICAL DIMENSIONS:
- Flashing height: 8" min. above roof surface
- Termination bar: Continuous, fastened 6" O.C.
- Cant strip: 4" × 4" typical
- Counter flashing overlap: 4" min.

NOTES:
- Prime metal before membrane application
- Seal all fastener penetrations
- Provide corner reinforcement patches
```

### Base Flashing at Curb
```
COMPONENTS:
1. Treated wood nailer at curb base
2. Cant strip at curb/deck intersection
3. Field membrane turned up and over cant
4. Base flashing membrane wrapped around curb
5. Metal flange at equipment/skylight
6. Sealant at all terminations

CRITICAL DIMENSIONS:
- Flashing height: Top of curb or min. 8"
- Curb height: 8" min. above roof (12" at drains)
- Cant: 4" × 4" typical

NOTES:
- Flash all four sides continuously
- Reinforce inside and outside corners
- Coordinate curb dimensions with equipment
```

### Edge Metal / Gravel Stop
```
COMPONENTS:
1. Wood nailer at roof edge
2. Membrane over nailer
3. Edge metal flange under membrane
4. Edge metal vertical face
5. Continuous cleat (if required)
6. Drip edge

CRITICAL DIMENSIONS:
- Flange width: 4" min.
- Vertical face: Per schedule
- Joint spacing: 10'-0" max.
- Expansion joints: Per design

NOTES:
- Hem all exposed edges
- Seal joints with compatible sealant
- Provide end dams at terminations
```

### Roof Drain Detail
```
COMPONENTS:
1. Drain bowl set in mastic
2. Clamping ring
3. Membrane sandwiched in clamping ring
4. Membrane flashing around drain
5. Gravel guard/strainer
6. Insulation tapered to drain

CRITICAL DIMENSIONS:
- Drain size: Per schedule (typically 4")
- Sump depth: 1" min. below membrane
- Flashing radius: 12" min. from drain edge

NOTES:
- Set drain at low point
- Verify leader connection before covering
- Install overflow drain within 10' (code requirement)
```

### Pipe Penetration Detail
```
COMPONENTS:
1. Pipe through roof deck
2. Membrane field
3. Pipe boot (size to match pipe)
4. Sealant at pipe/boot junction
5. Storm collar (for large pipes)
6. Clamping band

CRITICAL DIMENSIONS:
- Boot sizes: 1"-2", 2"-3", 3"-4", 4"-6", etc.
- Flashing height: 8" min. above roof
- Boot set in mastic bed

NOTES:
- Prime all metal surfaces
- Allow for pipe movement
- Verify pipe size before ordering boots
```

### Expansion Joint Detail
```
COMPONENTS:
1. Structural expansion joint
2. Insulation terminated at joint
3. Membrane terminated each side
4. Expansion joint cover
5. Bellows or flexible membrane
6. Metal flanges each side

CRITICAL DIMENSIONS:
- Joint width: Per structural
- Cover width: Joint + 8" min. each side
- Bellows depth: Per movement expected

NOTES:
- Coordinate with structural drawings
- Do not restrict joint movement
- Provide at all building expansion joints
```

## Schedules

### Drain Schedule Template
```
ROOF DRAIN SCHEDULE

| Mark | Size | Type | Manufacturer | Model | Location | Notes |
|------|------|------|--------------|-------|----------|-------|
| RD-1 | 4" | Primary | Zurn | Z100 | Grid A-3 | |
| RD-2 | 4" | Primary | Zurn | Z100 | Grid B-5 | |
| OD-1 | 4" | Overflow | Zurn | Z100-OF | Grid A-3 | Adj. to RD-1 |
| SC-1 | 6"×6" | Scupper | Custom | - | Grid C-1 | See Detail 5 |

Notes:
1. All drains to have cast iron body, poly-coated
2. Provide dome strainer at all primary drains
3. Overflow drains set 2" above primary drains
```

### Penetration Schedule Template
```
ROOF PENETRATION SCHEDULE

| Mark | Size | Type | Flashing | Location | Notes |
|------|------|------|----------|----------|-------|
| P-1 | 2" | Plumbing vent | Boot | Grid A-2 | |
| P-2 | 4" | Plumbing vent | Boot | Grid B-4 | |
| P-3 | 6" | Exhaust | Curb | Grid C-3 | See Detail 7 |
| P-4 | 1" | Conduit | Boot | Various | Typ. of 12 |
| P-5 | 3" | Gas vent | Boot | Grid D-2 | B-vent, maintain clearance |

Notes:
1. Verify all sizes in field before ordering
2. Maintain required clearances for B-vents
3. Provide pitch pockets for irregular shapes
```

### Curb Schedule Template
```
EQUIPMENT CURB SCHEDULE

| Mark | Size (LxWxH) | Equipment | Curb By | Flash By | Notes |
|------|--------------|-----------|---------|----------|-------|
| RTU-1 | 8'×6'×14" | Rooftop unit | Mech. | Roofer | Prefab curb |
| RTU-2 | 10'×8'×14" | Rooftop unit | Mech. | Roofer | Prefab curb |
| SKY-1 | 4'×4'×12" | Skylight | Roofer | Roofer | See arch. |
| EF-1 | 36"×36"×12" | Exhaust fan | Roofer | Roofer | |
| RH-1 | 36"×30"×12" | Roof hatch | Roofer | Roofer | Bilco type |

Notes:
1. All curbs min. 8" above roof surface
2. Curbs at drains min. 12" above roof surface
3. Verify all dimensions with equipment submittals
```

## Title Block Information

### Required Information
```
PROJECT INFORMATION:
- Project name
- Project address
- Owner
- Architect
- General contractor

DRAWING INFORMATION:
- Sheet title
- Sheet number
- Scale(s)
- Date
- Drawn by
- Checked by

REVISION BLOCK:
- Rev. number
- Date
- Description
- By

COMPANY INFORMATION:
- Company name
- Address
- Phone
- License number
- Logo
```

### Sheet Numbering Convention
```
Division 07 Shop Drawings:

SD-701    Roof Plan - Area A
SD-702    Roof Plan - Area B
SD-703    Roof Details (1)
SD-704    Roof Details (2)
SD-705    Edge Metal Details
SD-706    Schedules

Or:

SD-7.01   Roof Plan
SD-7.02   Roof Plan (continued)
SD-7.10   Base Flashing Details
SD-7.11   Edge Metal Details
SD-7.12   Drain Details
SD-7.13   Penetration Details
SD-7.20   Schedules
```

## Annotation Standards

### Standard Abbreviations
```
ROOFING ABBREVIATIONS:
ADH     Adhered
BUR     Built-up roofing
C.J.    Control joint
CNTR    Center
CONT    Continuous
E.J.    Expansion joint
EPDM    Ethylene propylene diene monomer
EQ      Equal
EXIST   Existing
F.O.    Face of
FLASH   Flashing
G.S.    Gravel stop
INSUL   Insulation
MAX     Maximum
MECH    Mechanical
MEM     Membrane
MIN     Minimum
MOD-BIT Modified bitumen
MTL     Metal
N.I.C.  Not in contract
N.T.S.  Not to scale
O.C.    On center
O.D.    Outside diameter
P.T.    Pressure treated
PVC     Polyvinyl chloride
R.D.    Roof drain
S.S.    Stainless steel
SIM     Similar
S.F.    Square feet
TPO     Thermoplastic polyolefin
TYP     Typical
U.N.O.  Unless noted otherwise
V.I.F.  Verify in field
W/      With
W.P.    Waterproofing
```

### Standard Notes

#### General Notes
```
GENERAL NOTES:

1. All work shall comply with contract documents including
   drawings, specifications, and addenda.

2. Contractor to verify all dimensions and conditions in
   field prior to fabrication.

3. Report any discrepancies to architect/engineer before
   proceeding.

4. All materials and installation per manufacturer's
   current published recommendations.

5. Refer to specification section [07 XX 00] for material
   and installation requirements.

6. Coordinate all penetrations with mechanical, electrical,
   and plumbing drawings.

7. All flashing heights are minimums measured from finished
   roof surface.

8. Provide shop drawings for all sheet metal fabrications.
```

#### Material Notes
```
MATERIAL NOTES:

1. Membrane: [Manufacturer] [Product], [thickness],
   [color] per specification section 07 XX 00.

2. Insulation: [Manufacturer] [Product], R-[value],
   [thickness] per specification section 07 22 00.

3. Flashing: [Manufacturer] [Product] per specification
   section 07 62 00.

4. Edge metal: [Gauge] [material] with [finish] per
   specification section 07 62 00.

5. Sealant: [Manufacturer] [Product] per specification
   section 07 92 00.

6. Fasteners: FM approved for specified wind uplift.
```

#### Detail Notes
```
DETAIL NOTES:

1. Prime all metal surfaces before membrane application.

2. Provide corner reinforcement at all inside and outside
   corners.

3. Seal all terminations with specified sealant.

4. Maintain minimum [X]" clearance from roof surface to
   bottom of equipment.

5. Cant strips to be [manufacturer] preformed or field-cut
   from insulation.

6. All dimensions are to face of finished materials unless
   noted otherwise.
```

## Shop Drawing Review Checklist

### Before Submitting
- [ ] All details match current contract documents
- [ ] Addenda incorporated
- [ ] RFI responses incorporated
- [ ] Manufacturer/products match approved submittal
- [ ] All dimensions verified
- [ ] All penetrations shown and scheduled
- [ ] All drains shown and scheduled
- [ ] All curbs shown and scheduled
- [ ] Edge conditions detailed
- [ ] Expansion joints shown
- [ ] Notes reference correct spec sections
- [ ] Title block complete
- [ ] Sheet numbered correctly
- [ ] Drawn to scale (and noted)
- [ ] North arrow on plans
- [ ] Grid lines match architectural

### Common Rejection Reasons
1. Dimensions don't match architectural
2. Missing details for unique conditions
3. Products don't match approved submittal
4. Missing penetrations or drains
5. Incorrect scale
6. Missing dimensions
7. Notes reference wrong spec section
8. Edge metal profile incorrect
9. Flashing heights don't meet minimum
10. Missing revision from addenda/RFI

## AutoCAD Productivity Tips

### Blocks to Create
- Drain symbols (plan view)
- North arrow
- Scale bars
- Section/detail markers
- Penetration symbols
- Slope arrows
- Revision clouds
- Title block

### Templates to Maintain
- Sheet template with title block
- Layer template with standards
- Detail library (common details)
- Standard notes library
- Dimension styles
- Text styles

### File Naming Convention
```
[ProjectNumber]-[Discipline]-[SheetNumber]-[Description].dwg

Examples:
2024-001-SD-701-RoofPlan.dwg
2024-001-SD-702-RoofDetails.dwg
2024-001-SD-703-EdgeMetal.dwg
```

## Coordination Requirements

### With Architect
- Verify building dimensions
- Confirm roof slopes
- Coordinate edge conditions
- Verify penetration locations
- Confirm curb locations and sizes
- Review flashing heights at walls

### With Structural
- Verify deck type
- Confirm expansion joint locations
- Coordinate blocking requirements
- Verify load capacity for equipment

### With Mechanical
- Verify RTU locations and sizes
- Confirm curb dimensions
- Coordinate penetration locations
- Verify ductwork penetrations

### With Electrical
- Verify conduit penetrations
- Coordinate lightning protection
- Confirm equipment locations

### With Plumbing
- Verify drain locations
- Confirm vent locations
- Coordinate overflow drains

## Questions to Ask User

1. "What project is this for?" (Get project number, name)
2. "What roofing system is specified?" (TPO, EPDM, mod-bit, etc.)
3. "Do you have the architectural roof plan?"
4. "Are there any RFIs or addenda to incorporate?"
5. "What details need to be developed?"
6. "What's the scale for the roof plan?"
7. "Are there equipment curbs I need to coordinate?"
8. "What manufacturer products are approved?"
