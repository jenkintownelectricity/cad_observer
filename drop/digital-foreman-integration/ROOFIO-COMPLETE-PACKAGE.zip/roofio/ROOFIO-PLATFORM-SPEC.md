# ROOFIO Platform Specification
## Complete Data-Linked AI Assistant System for Roofing Contractors
### Version 1.0 - Claude Code Ready

---

## EXECUTIVE SUMMARY

This specification defines a **unified data platform** where all forms, documents, and AI functions share a **single source of truth**. Every form auto-populates from job data. Every AI action logs to the job record. Every position (human or AI) works from the same synchronized data.

**Core Principle**: Data flows DOWN from Project → Job → Forms. Data flows UP from Forms → Job → Reports.

---

## PART 1: DATA ARCHITECTURE

### 1.1 Core Entity Relationships

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ROOFIO DATA MODEL                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  COMPANY (root)                                                              │
│  ├── company_id, name, license_no, insurance_info, tax_id                   │
│  ├── default_markup, warranty_terms, payment_terms                          │
│  │                                                                          │
│  ├── CONTACTS (shared pool)                                                 │
│  │   ├── contact_id, type (owner/gc/architect/sub/supplier/inspector)      │
│  │   ├── name, company, email, phone, address                              │
│  │   └── relationship_history[], notes                                      │
│  │                                                                          │
│  ├── EMPLOYEES                                                              │
│  │   ├── employee_id, name, role, certifications[], hourly_rate            │
│  │   ├── emergency_contact, training_records[]                             │
│  │   └── assigned_projects[]                                                │
│  │                                                                          │
│  ├── PRODUCTS (material library)                                            │
│  │   ├── product_id, manufacturer, name, sku, unit, unit_cost              │
│  │   ├── spec_section, fm_approval, warranty_years                         │
│  │   └── supplier_id, lead_time                                            │
│  │                                                                          │
│  └── PROJECTS                                                               │
│      ├── project_id, name, address, type (commercial/residential)          │
│      ├── gc_contact_id, owner_contact_id, architect_contact_id             │
│      ├── contract_amount, start_date, end_date, status                     │
│      ├── spec_sections[], insurance_requirements                           │
│      │                                                                      │
│      ├── JOBS (individual scopes within project)                           │
│      │   ├── job_id, scope_description, area_sqft                          │
│      │   ├── system_type, warranty_type, attachment_method                 │
│      │   ├── original_amount, change_orders_total, current_amount          │
│      │   ├── billed_to_date, retention_held, balance_due                   │
│      │   │                                                                  │
│      │   ├── SCHEDULE_OF_VALUES[]                                          │
│      │   │   ├── line_item, description, scheduled_value                   │
│      │   │   ├── work_completed_previous, work_completed_current           │
│      │   │   ├── materials_stored, total_completed, percent_complete       │
│      │   │   └── balance_to_finish, retainage                              │
│      │   │                                                                  │
│      │   ├── SUBMITTALS[]                                                  │
│      │   │   ├── submittal_id, number, spec_section, description           │
│      │   │   ├── submitted_date, required_date, status                     │
│      │   │   ├── reviewer_contact_id, response, response_date              │
│      │   │   └── attachments[], revision_history[]                         │
│      │   │                                                                  │
│      │   ├── RFIs[]                                                        │
│      │   │   ├── rfi_id, number, subject, question, drawing_ref            │
│      │   │   ├── submitted_to_id, submitted_date, required_date            │
│      │   │   ├── response, response_date, cost_impact, schedule_impact     │
│      │   │   └── attachments[], linked_change_orders[]                     │
│      │   │                                                                  │
│      │   ├── CHANGE_ORDERS[]                                               │
│      │   │   ├── co_id, number, description, reason                        │
│      │   │   ├── labor_cost, material_cost, markup, total                  │
│      │   │   ├── submitted_date, approved_date, status                     │
│      │   │   ├── time_extension_days, linked_rfi_id                        │
│      │   │   └── approval_signatures[]                                     │
│      │   │                                                                  │
│      │   ├── DAILY_REPORTS[]                                               │
│      │   │   ├── report_id, date, weather, temp_high, temp_low             │
│      │   │   ├── crew_members[], hours_worked, work_performed              │
│      │   │   ├── materials_received[], equipment_used[]                    │
│      │   │   ├── visitors[], delays, safety_incidents                      │
│      │   │   └── photos[], superintendent_id                               │
│      │   │                                                                  │
│      │   ├── INSPECTIONS[]                                                 │
│      │   │   ├── inspection_id, type, date, inspector_id                   │
│      │   │   ├── checklist_items[], passed, notes                          │
│      │   │   ├── deficiencies[], photos[], follow_up_required              │
│      │   │   └── linked_punch_list_id                                      │
│      │   │                                                                  │
│      │   ├── PUNCH_LISTS[]                                                 │
│      │   │   ├── punch_id, created_date, items[]                           │
│      │   │   │   └── item: location, description, assigned_to, status      │
│      │   │   └── completion_date, signed_off_by                            │
│      │   │                                                                  │
│      │   ├── PAY_APPLICATIONS[]                                            │
│      │   │   ├── pay_app_id, number, period_from, period_to                │
│      │   │   ├── original_contract, change_orders_approved                 │
│      │   │   ├── contract_sum_to_date, completed_to_date                   │
│      │   │   ├── stored_materials, total_earned, retainage                 │
│      │   │   ├── less_previous_payments, current_due                       │
│      │   │   ├── submitted_date, certified_date, paid_date                 │
│      │   │   └── lien_waiver_id, g702_pdf, g703_pdf                        │
│      │   │                                                                  │
│      │   ├── LIEN_WAIVERS[]                                                │
│      │   │   ├── waiver_id, type (conditional/unconditional)               │
│      │   │   ├── through_date, amount, pay_app_id                          │
│      │   │   └── signed_date, notarized                                    │
│      │   │                                                                  │
│      │   ├── SAFETY_DOCS[]                                                 │
│      │   │   ├── doc_id, type (JHA/toolbox/incident/permit)                │
│      │   │   ├── date, attendees[], content, signatures[]                  │
│      │   │   └── linked_daily_report_id                                    │
│      │   │                                                                  │
│      │   └── CLOSEOUT_DOCS[]                                               │
│      │       ├── doc_id, type, received_date, status                       │
│      │       └── file_url, verified_by                                     │
│      │                                                                      │
│      └── DRAWINGS[]                                                         │
│          ├── drawing_id, number, title, revision                           │
│          ├── file_url, uploaded_date                                       │
│          └── linked_rfis[], linked_submittals[]                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Data Linking Rules

**EVERY FORM AUTO-POPULATES FROM PARENT DATA:**

| Form | Pre-fills From |
|------|----------------|
| RFI | Project name, address, GC contact, Architect contact, Drawing references |
| Submittal | Project name, Spec sections, Contractor info, Reviewer contacts |
| Change Order | Project, Job, Original contract, Related RFI, Labor/material rates |
| Pay Application | All SOV data, Previous payments, Change orders, Retainage rate |
| Daily Report | Project, Weather (auto-fetch), Crew roster, Equipment assigned |
| Inspection | Project, Job, Checklist template, Inspector from contacts |
| Punch List | Inspection deficiencies, Location data, Assignable employees |
| JHA | Project, Location, Scope, Standard hazards for roof type |
| Lien Waiver | Pay application data, Company info, Through-date |

**CASCADING UPDATES:**
- Change Order approved → Updates Job.current_amount → Updates SOV → Updates Pay App calculations
- Daily Report logged → Updates Job.work_completed → Available in next Pay App
- Inspection failed → Creates Punch List → Blocks final Pay App until resolved
- RFI answered with cost impact → Auto-generates Change Order draft

---

## PART 2: FORM LIBRARY (VERIFIED COMPLETE)

### 2.1 Forms by Position - VALIDATED

Based on research of AccuLynx, Procore, JobProgress, and industry standards, your original list is **95% complete**. Here's the final validated list with additions:

#### ESTIMATOR (8 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Bid Proposal | Formal bid submission | Contact, Project, Quantities |
| ✅ Scope of Work | Detailed work description | Project, System type |
| ✅ Material Schedule | BOM with quantities | Takeoff, Product library |
| ✅ Unit Price Schedule | Line item pricing | Products, Labor rates |
| ✅ Exclusions/Clarifications | What's NOT included | Template + Project |
| ✅ Bid Bond Request | Surety request | Project value, Company |
| ➕ **Bid Comparison Sheet** | Compare competitor bids | Manual entry |
| ➕ **Subcontractor Quote Request** | Get sub pricing | Project, Scope |

#### PROJECT MANAGER (9 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Submittal Cover Sheet | Track product approvals | Project, Spec section |
| ✅ RFI Form | Request clarification | Project, Drawing, Contact |
| ✅ Change Order Request | Document scope changes | Job, RFI, Pricing |
| ✅ Meeting Minutes | Record decisions | Project, Attendees |
| ✅ Schedule Update Notice | Communicate delays | Project, Schedule |
| ✅ Delay Notification | Formal delay claim | Project, Weather/RFI data |
| ✅ Progress Payment Application | AIA G702/G703 | SOV, Previous payments |
| ➕ **Transmittal** | Cover sheet for docs sent | Project, Recipient |
| ➕ **Notice to Proceed** | Start work authorization | Contract, Project |

#### SHOP DRAWING DETAILER (6 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Shop Drawing Transmittal | Submit drawings for review | Project, Drawing list |
| ✅ Drawing Register/Log | Track all drawings | Project, Auto-generated |
| ✅ Revision History Sheet | Log changes | Drawing, Previous revisions |
| ✅ Detail Index | Catalog of details | Drawing set |
| ✅ Keynote Legend | Define symbols | Project standards |
| ➕ **Drawing Review Response** | Address reviewer comments | Submittal response |

#### SPECIFICATION WRITER (5 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Specification Section | CSI 3-part format | Template, Products |
| ✅ Product Data Sheet Compilation | Organize manufacturer data | Products, Submittals |
| ✅ Substitution Request | Request product swap | Original spec, Alt product |
| ✅ Basis of Design Summary | Document BOD products | Spec sections |
| ➕ **Spec Compliance Checklist** | Verify installation matches spec | Spec, Inspection |

#### QC / INSPECTOR (8 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Pre-Installation Checklist | Verify readiness | Job, Manufacturer requirements |
| ✅ Progress Inspection Report | Document ongoing work | Job, Checklist template |
| ✅ Final Inspection Report | Sign-off inspection | Job, All prior inspections |
| ✅ Punch List | Deficiency tracking | Inspection findings |
| ✅ Test Report (flood/ELD/core) | Document test results | Job, Test type template |
| ✅ Non-Conformance Report | Document defects | Inspection, Spec reference |
| ✅ Warranty Inspection Checklist | Pre-warranty check | Manufacturer requirements |
| ➕ **Photo Documentation Log** | Organize progress photos | Job, Date, Location |

#### SAFETY OFFICER (8 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Job Hazard Analysis (JHA) | Identify hazards | Job type, Location, Template |
| ✅ Toolbox Talk Sign-In | Document safety meetings | Project, Crew, Topic |
| ✅ Incident/Accident Report | Document injuries | Project, Employee, Date |
| ✅ Safety Inspection Checklist | Site safety audit | OSHA requirements |
| ✅ Hot Work Permit | Authorize torch work | Project, Location, Date |
| ✅ Fall Protection Plan | Document fall prevention | Job, Height, Equipment |
| ✅ Equipment Inspection Log | Track equipment safety | Equipment list |
| ➕ **OSHA 300 Log Entry** | Recordable incident log | Incident report |

#### SUPERINTENDENT / FOREMAN (8 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Daily Field Report | Document daily activities | Project, Weather, Crew |
| ✅ T&M (Time & Materials) Ticket | Track extra work | Job, Employee, Materials |
| ✅ Material Receiving Log | Document deliveries | PO, Supplier, Products |
| ✅ Delivery Schedule | Plan material drops | Job, Supplier calendar |
| ✅ 2-Week Lookahead | Short-term schedule | Master schedule |
| ✅ Extra Work Authorization | Approve additional work | Job, CO pending |
| ✅ Weather Delay Log | Document weather impacts | Daily report, Weather API |
| ➕ **Crew Assignment Sheet** | Daily crew deployment | Employees, Jobs |

#### ACCOUNTS / ADMINISTRATION (9 Forms)
| Form | Purpose | Pre-fill Source |
|------|---------|-----------------|
| ✅ Progress Invoice (G702/G703) | Request payment | SOV, Previous payments |
| ✅ Lien Waiver (Conditional) | Release lien rights | Pay app, Amount |
| ✅ Lien Waiver (Unconditional) | Final lien release | Pay app, Amount |
| ✅ Certificate of Insurance Request | Request updated COI | Vendor, Project |
| ✅ Contract Exhibit Checklist | Track contract docs | Project, Template |
| ✅ Closeout Document Checklist | Track closeout | Job, Required docs |
| ✅ Warranty Letter | Issue workmanship warranty | Job, Company terms |
| ➕ **Subcontractor Pay Request** | Sub payment processing | Sub contract, SOV |
| ➕ **Notice of Completion** | Formal project completion | Project, Final inspection |

### 2.2 Form Count Summary

| Position | Original | Added | Final |
|----------|----------|-------|-------|
| Estimator | 6 | 2 | **8** |
| Project Manager | 7 | 2 | **9** |
| Shop Drawing Detailer | 5 | 1 | **6** |
| Specification Writer | 4 | 1 | **5** |
| QC/Inspector | 7 | 1 | **8** |
| Safety Officer | 7 | 1 | **8** |
| Superintendent | 7 | 1 | **8** |
| Accounts | 6 | 3 | **9** |
| **TOTAL** | **49** | **12** | **61** |

---

## PART 3: UI/UX SPECIFICATION

### 3.1 Mode Toggle System

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ROOFIO CONTROL CENTER                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─ COMPANY SETTINGS ──────────────────────────────────────────────────┐    │
│  │                                                                      │    │
│  │  POSITION CONFIGURATION                    [Toggle All AI] [Reset]  │    │
│  │  ═══════════════════════════════════════════════════════════════    │    │
│  │                                                                      │    │
│  │  ESTIMATOR          ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │  PROJECT MANAGER    ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │  SHOP DETAILER      ○ OFF   ◉ ASSIST   ○ FULL AI     ← You        │    │
│  │  SPEC WRITER        ○ OFF   ○ ASSIST   ◉ FULL AI                   │    │
│  │  QC / INSPECTOR     ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │  SAFETY OFFICER     ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │  SUPERINTENDENT     ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │  ACCOUNTS           ○ OFF   ◉ ASSIST   ○ FULL AI                   │    │
│  │                                                                      │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─ FORM SETS ─────────────────────────────────────────────────────────┐    │
│  │                                                                      │    │
│  │  ☑ Core Forms (RFI, Submittal, CO, Pay App)              REQUIRED   │    │
│  │  ☑ Daily Operations (Daily Report, T&M, Delivery)        ENABLED    │    │
│  │  ☑ Safety & Compliance (JHA, Toolbox, Incident)          ENABLED    │    │
│  │  ☑ Closeout (Warranty, Punch, Lien Waiver)               ENABLED    │    │
│  │  ☐ Estimating (Bid, SOW, Unit Pricing)                   DISABLED   │    │
│  │  ☐ Advanced Specs (CSI Sections)                         DISABLED   │    │
│  │                                                                      │    │
│  │  [Expand to Configure Individual Forms]                              │    │
│  └──────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Visual Badge System

```
MODE INDICATORS (Always Visible in Header)
═════════════════════════════════════════

🤖 FULL AI MODE
┌──────────────────────────────────────────────┐
│  🤖 [ROOFIO AUTONOMOUS]                       │
│  ▸ Handling: Submittals, Schedule, RFIs      │
│  ▸ Actions Pending: 3  Completed Today: 12   │
│  ▸ [View Activity Log]                        │
└──────────────────────────────────────────────┘

🧑‍💼 ASSIST MODE
┌──────────────────────────────────────────────┐
│  🧑‍💼 [ROOFIO ASSIST] Armand                   │
│  ▸ Available: [New RFI] [New CO] [New DA]    │
│  ▸ Suggestions: 2 pending reviews            │
│  ▸ [Quick Actions ▼]                          │
└──────────────────────────────────────────────┘

⚫ DISABLED
┌──────────────────────────────────────────────┐
│  ⚫ Estimating [DISABLED]                     │
│  ▸ [Enable Module]                            │
└──────────────────────────────────────────────┘
```

### 3.3 Job Dashboard (Data-Linked View)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  JOB: JHU Homewood Library - Roof Replacement                    [Edit Job] │
│  Status: IN PROGRESS   |   Phase: Installation   |   Weather: 72°F Clear   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─ QUICK STATS ────────────────────────────────────────────────────────┐   │
│  │  Contract: $847,500 │ Billed: $423,750 (50%) │ Due: $42,375          │   │
│  │  COs: +$23,400 (2 approved) │ Retention: $42,375                     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─ ACTIVE ITEMS ─────────────────────────┬─ QUICK ACTIONS ─────────────┐   │
│  │                                        │                              │   │
│  │  ⚠️  RFI #007 - Due Tomorrow           │  [+ Daily Report]            │   │
│  │  📋 Submittal #012 - Under Review      │  [+ RFI from Drawing]        │   │
│  │  💰 Pay App #5 - Ready to Submit       │  [+ Change Order]            │   │
│  │  📸 Inspection Due in 3 Days           │  [+ T&M Ticket]              │   │
│  │                                        │  [+ Photo Upload]            │   │
│  └────────────────────────────────────────┴──────────────────────────────┘   │
│                                                                              │
│  ┌─ DOCUMENTS ──────────────────────────────────────────────────────────┐   │
│  │  [Submittals: 12] [RFIs: 7] [COs: 2] [Pay Apps: 4] [Daily: 23]       │   │
│  │  [Safety: 8] [Photos: 156] [Drawings: 34] [Closeout: 0/12]           │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─ LINKED CONTACTS ────────────────────────────────────────────────────┐   │
│  │  Owner: Johns Hopkins Facilities │ GC: Turner Construction           │   │
│  │  Architect: Ayers Saint Gross    │ Inspector: Bureau Veritas         │   │
│  │  [All contacts pre-fill into forms]                                  │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.4 One-Click Form Generation (ASSIST Mode)

```
USER TRIGGERS ONE-CLICK FORM
════════════════════════════════════════════════════════════════════

TRIGGER: User clicks [+ New RFI] from Job Dashboard

SYSTEM RESPONSE:
┌─────────────────────────────────────────────────────────────────────────────┐
│  NEW RFI                                                    JHU Homewood    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─ PRE-FILLED (from job data) ─────────────────────────────────────────┐   │
│  │  Project: JHU Homewood Library                          [locked] ✓   │   │
│  │  Address: 3400 N Charles St, Baltimore MD               [locked] ✓   │   │
│  │  To: Ayers Saint Gross (Sarah Chen - Architect)         [change] ▼   │   │
│  │  From: Lefebvre Design Solutions                        [locked] ✓   │   │
│  │  RFI #: 008 (auto-increment)                            [locked] ✓   │   │
│  │  Date: December 7, 2025                                 [locked] ✓   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─ YOU COMPLETE ───────────────────────────────────────────────────────┐   │
│  │  Subject: ________________________________________________           │   │
│  │                                                                      │   │
│  │  Drawing Ref: [Select from job drawings ▼] or type: ____            │   │
│  │  Spec Section: [07 54 00 - TPO ▼] (from job spec sections)          │   │
│  │                                                                      │   │
│  │  Question:                                                           │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │                                                                │ │   │
│  │  │  [🎤 Voice-to-Text]  [📸 Attach Photo]  [🤖 AI Draft]         │ │   │
│  │  └────────────────────────────────────────────────────────────────┘ │   │
│  │                                                                      │   │
│  │  Cost Impact: ○ Yes ○ No ○ TBD    Schedule Impact: ○ Yes ○ No ○ TBD │   │
│  │                                                                      │   │
│  │  Attachments: [+ Add Files]                                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  [Save Draft]                      [Submit RFI]                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.5 Form Sets Toggle (Minimal/Clean Approach)

```
FORM CONFIGURATION (Per Company or Per Project)
═══════════════════════════════════════════════

PRESET TEMPLATES:
┌─────────────────────────────────────────────────────────────────────────────┐
│  ○ Residential Simple (15 forms)                                            │
│  ○ Commercial Standard (35 forms)                                           │
│  ◉ Commercial Full (61 forms)                                               │
│  ○ Custom                                                                   │
└─────────────────────────────────────────────────────────────────────────────┘

CUSTOM CONFIGURATION:
┌─────────────────────────────────────────────────────────────────────────────┐
│  FORM SET                        ENABLED    FORMS    [Expand]               │
├─────────────────────────────────────────────────────────────────────────────┤
│  📋 Core Project Management       [ON]       9       [▼]                    │
│     ├─ ☑ RFI Form                                                          │
│     ├─ ☑ Submittal Cover Sheet                                             │
│     ├─ ☑ Change Order Request                                              │
│     ├─ ☑ Progress Payment (G702/G703)                                      │
│     ├─ ☑ Transmittal                                                       │
│     ├─ ☑ Meeting Minutes                                                   │
│     ├─ ☐ Schedule Update Notice                                            │
│     ├─ ☐ Delay Notification                                                │
│     └─ ☐ Notice to Proceed                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│  🔧 Daily Operations              [ON]       8       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  ⚠️ Safety & Compliance           [ON]       8       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  📊 Estimating                    [OFF]      8       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  ✅ QC & Inspections              [ON]       8       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  📁 Closeout                      [ON]       9       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  📐 Shop Drawings                 [ON]       6       [▶]                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  📝 Specifications                [OFF]      5       [▶]                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## PART 4: AI MODE SPECIFICATIONS

### 4.1 Full AI Mode Functions

```
POSITION: PROJECT MANAGER - FULL AI 🤖
══════════════════════════════════════

AUTOMATED TRIGGERS:
┌─────────────────────────────────────────────────────────────────────────────┐
│  TRIGGER                          │  AI ACTION                              │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Submittal due in 7 days          │  Draft reminder email to submitter     │
│  Submittal due in 3 days          │  Escalate: reminder + cc PM            │
│  Submittal overdue                │  Log delay, notify GC, flag in report  │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  RFI response received            │  Log response, check for cost impact   │
│  RFI response has cost impact     │  Draft Change Order, link to RFI       │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Monthly billing period ends      │  Generate Pay App draft from SOV       │
│  Pay App approved                 │  Generate Conditional Lien Waiver      │
│  Payment received                 │  Generate Unconditional Lien Waiver    │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Daily report logged              │  Update job progress metrics           │
│  Weather forecast: rain           │  Log weather delay, notify crew        │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Project milestone reached        │  Generate progress report, notify team │
│  Job reaches 95% complete         │  Generate closeout checklist           │
└─────────────────────────────────────────────────────────────────────────────┘

AUTONOMOUS OUTPUTS:
- Submittal log (auto-updated)
- RFI log (auto-updated)
- Change order log (auto-updated)
- Weekly status email (auto-generated)
- Monthly progress report (auto-generated)
```

### 4.2 Assist Mode Functions

```
POSITION: SUPERINTENDENT - ASSIST MODE 🧑‍💼
═══════════════════════════════════════════

ONE-CLICK ACTIONS:
┌─────────────────────────────────────────────────────────────────────────────┐
│  USER ACTION                      │  AI RESPONSE                            │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Tap [+ Daily Report]             │  Pre-fill: project, date, weather,     │
│                                   │  yesterday's crew, equipment. User     │
│                                   │  adds: work performed, notes.          │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Upload photos                    │  Auto-tag with date, location, user.   │
│                                   │  Suggest: "Add to Daily Report?"       │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Voice memo                       │  Transcribe, suggest form type:        │
│                                   │  "Sounds like a T&M ticket. Create?"   │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  Tap [Material Received]          │  Show expected deliveries, scan/select │
│                                   │  PO, verify quantities, log receipt.   │
├───────────────────────────────────┼─────────────────────────────────────────┤
│  View 2-Week Lookahead            │  Auto-generate from master schedule,   │
│                                   │  flag conflicts, suggest crew assign.  │
└─────────────────────────────────────────────────────────────────────────────┘

SUGGESTIONS (Not Auto-Executed):
- "Rain forecast tomorrow. Want me to draft a weather delay notice?"
- "Yesterday's T&M ticket wasn't submitted. Reminder sent to you."
- "Crew logged 12 hours OT this week. Flag for PM review?"
```

---

## PART 5: DATA SYNCHRONIZATION RULES

### 5.1 Cascading Updates

```
DATA FLOW DIAGRAM
═════════════════

                    ┌─────────────┐
                    │   COMPANY   │
                    └──────┬──────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
     ┌─────▼─────┐   ┌─────▼─────┐   ┌─────▼─────┐
     │ CONTACTS  │   │ EMPLOYEES │   │ PRODUCTS  │
     └─────┬─────┘   └─────┬─────┘   └─────┬─────┘
           │               │               │
           └───────────────┼───────────────┘
                           │
                    ┌──────▼──────┐
                    │   PROJECT   │
                    └──────┬──────┘
                           │
                    ┌──────▼──────┐
                    │     JOB     │──────────────────────────────────┐
                    └──────┬──────┘                                  │
                           │                                         │
        ┌────────┬────────┬┴───────┬────────┬────────┐              │
        │        │        │        │        │        │              │
   ┌────▼───┐┌───▼───┐┌───▼───┐┌───▼───┐┌───▼───┐┌───▼───┐         │
   │  SOV   ││  RFI  ││Submit.││  CO   ││ Daily ││Inspect│         │
   └────┬───┘└───┬───┘└───┬───┘└───┬───┘└───┬───┘└───┬───┘         │
        │        │        │        │        │        │              │
        │        └────────┴────────┤        │        │              │
        │                          │        │        │              │
        │              ┌───────────▼───────▼────────▼──────────┐   │
        │              │                                        │   │
        └──────────────►         PAY APPLICATION               ◄───┘
                       │       (G702 / G703)                    │
                       │                                        │
                       └───────────────┬────────────────────────┘
                                       │
                                       ▼
                              ┌────────────────┐
                              │  LIEN WAIVER   │
                              └────────────────┘


UPDATE RULES:
─────────────
1. Contact updated → All forms using that contact update
2. Product price updated → All estimates using that product recalculate
3. Change Order approved → Job.current_amount updates → SOV updates → Pay App recalculates
4. Daily Report logged → Job.percent_complete updates (optional)
5. Inspection fails → Punch list created → Closeout blocked until resolved
6. Pay App paid → Lien Waiver auto-generated
7. All closeout docs received → Job status → COMPLETE
```

### 5.2 Required Validations

```
FORM SUBMISSION RULES
═════════════════════

PAY APPLICATION:
├─ ✓ SOV must exist with at least one line item
├─ ✓ Total completed cannot exceed contract sum + approved COs
├─ ✓ Retainage calculation must match contract terms
├─ ✓ Previous payment amounts must match prior Pay App
└─ ✓ Required attachments: SOV backup, Conditional Lien Waiver

CHANGE ORDER:
├─ ✓ Must link to RFI or document justification
├─ ✓ Labor rates must match contract schedule
├─ ✓ Markup must match contract terms
└─ ✓ Cannot exceed PM approval limit without owner signature

RFI:
├─ ✓ Must have question text
├─ ✓ Must have required response date
└─ ✓ Drawing reference recommended but not required

DAILY REPORT:
├─ ✓ Must have at least one crew member
├─ ✓ Must have work performed description
└─ ✓ Weather auto-populated from API, editable

INSPECTION:
├─ ✓ Must complete all checklist items
├─ ✓ Deficiencies must have description and photo
└─ ✓ Failed inspection creates Punch List automatically
```

---

## PART 6: IMPLEMENTATION ROADMAP

### Phase 1: Data Foundation (Weeks 1-2)
```
□ Database schema (PostgreSQL/Supabase)
□ Core entities: Company, Project, Job, Contact, Employee, Product
□ Authentication & multi-tenancy
□ Basic CRUD APIs
```

### Phase 2: Core Forms (Weeks 3-4)
```
□ Form engine with pre-fill logic
□ RFI form + submission flow
□ Submittal form + tracking
□ Change Order form + approval workflow
□ Pay Application (G702/G703) generator
□ PDF export for all forms
```

### Phase 3: Daily Operations (Weeks 5-6)
```
□ Daily Report form + photo integration
□ T&M Ticket form
□ Material Receiving Log
□ 2-Week Lookahead generator
□ Weather API integration
```

### Phase 4: Safety & Compliance (Week 7)
```
□ JHA form with hazard library
□ Toolbox Talk generator
□ Incident Report form
□ Safety Inspection checklists
```

### Phase 5: Position Modes (Week 8)
```
□ Mode toggle system (OFF/ASSIST/FULL AI)
□ AI trigger engine for FULL AI mode
□ One-click actions for ASSIST mode
□ Activity logging for all AI actions
```

### Phase 6: Closeout & Reporting (Week 9)
```
□ Closeout checklist with doc tracking
□ Warranty Letter generator
□ Lien Waiver generator
□ Job completion report
□ Dashboard metrics
```

### Phase 7: Polish & Mobile (Week 10)
```
□ Mobile-responsive forms
□ Offline capability for field use
□ Voice-to-text integration
□ Photo annotation tools
□ Push notifications
```

---

## PART 7: TECH STACK RECOMMENDATION

```
RECOMMENDED STACK
═════════════════

FRONTEND:
├─ Next.js 14 (App Router)
├─ Tailwind CSS + shadcn/ui
├─ React Hook Form (form state)
├─ TanStack Query (data fetching)
└─ Zustand (global state)

BACKEND:
├─ Supabase (PostgreSQL + Auth + Storage + Realtime)
├─ Edge Functions (serverless logic)
└─ Anthropic API (Claude for AI features)

MOBILE:
├─ React Native + Expo
├─ Or: Progressive Web App (PWA)
└─ Offline: Supabase offline-first

PDF GENERATION:
├─ react-pdf/renderer (browser)
├─ Or: Puppeteer (server-side)
└─ Templates stored as React components

INTEGRATIONS:
├─ Weather: OpenWeatherMap API
├─ Accounting: QuickBooks API
├─ Measurements: EagleView API
└─ Storage: Supabase Storage or S3
```

---

## APPENDIX A: FORM FIELD MAPPINGS

### RFI Form - Complete Field Map
```json
{
  "form": "RFI",
  "fields": [
    {"name": "project_name", "source": "project.name", "editable": false},
    {"name": "project_address", "source": "project.address", "editable": false},
    {"name": "rfi_number", "source": "auto_increment", "editable": false},
    {"name": "date", "source": "current_date", "editable": false},
    {"name": "to_contact", "source": "project.architect_contact", "editable": true},
    {"name": "from_company", "source": "company.name", "editable": false},
    {"name": "subject", "source": null, "editable": true, "required": true},
    {"name": "drawing_ref", "source": "project.drawings[]", "editable": true},
    {"name": "spec_section", "source": "job.spec_sections[]", "editable": true},
    {"name": "question", "source": null, "editable": true, "required": true},
    {"name": "suggested_solution", "source": null, "editable": true},
    {"name": "cost_impact", "source": null, "editable": true, "options": ["Yes", "No", "TBD"]},
    {"name": "schedule_impact", "source": null, "editable": true, "options": ["Yes", "No", "TBD"]},
    {"name": "required_date", "source": "auto_calculate", "editable": true},
    {"name": "attachments", "source": null, "editable": true}
  ]
}
```

### Pay Application (G702) - Complete Field Map
```json
{
  "form": "G702",
  "fields": [
    {"name": "to_owner", "source": "project.owner_contact", "editable": false},
    {"name": "from_contractor", "source": "company", "editable": false},
    {"name": "project", "source": "project.name", "editable": false},
    {"name": "application_no", "source": "auto_increment", "editable": false},
    {"name": "period_to", "source": null, "editable": true, "required": true},
    {"name": "contract_date", "source": "job.contract_date", "editable": false},
    {"name": "architect", "source": "project.architect_contact", "editable": false},
    
    {"name": "line_1_original_contract", "source": "job.original_amount", "editable": false},
    {"name": "line_2_change_orders", "source": "sum(job.change_orders where approved)", "editable": false},
    {"name": "line_3_contract_sum_to_date", "source": "calculated: line_1 + line_2", "editable": false},
    {"name": "line_4_total_completed", "source": "sum(sov.total_completed)", "editable": false},
    {"name": "line_5_retainage", "source": "calculated: line_4 * retainage_rate", "editable": false},
    {"name": "line_6_total_earned_less_retainage", "source": "calculated: line_4 - line_5", "editable": false},
    {"name": "line_7_less_previous_certificates", "source": "sum(previous_pay_apps.amount_certified)", "editable": false},
    {"name": "line_8_current_payment_due", "source": "calculated: line_6 - line_7", "editable": false},
    {"name": "line_9_balance_to_finish", "source": "calculated: line_3 - line_4", "editable": false}
  ]
}
```

---

## APPENDIX B: AI PROMPT TEMPLATES

### RFI Draft Assistant
```
SYSTEM: You are a construction RFI drafting assistant for a roofing contractor.

CONTEXT:
- Project: {project.name}
- Spec Section: {selected_spec_section}
- Drawing: {selected_drawing}

USER INPUT: {user_description}

TASK: Draft a professional RFI question that:
1. Clearly states the issue or ambiguity
2. References the specific drawing/spec section
3. Suggests a potential solution if appropriate
4. Uses formal construction language
5. Is concise but complete

OUTPUT FORMAT:
Subject: [One line summary]
Question: [Clear, professional question]
Suggested Solution: [Optional recommendation]
```

### Daily Report Generator
```
SYSTEM: You are a construction daily report assistant.

CONTEXT:
- Project: {project.name}
- Date: {today}
- Weather: {weather_api_data}
- Yesterday's Crew: {yesterday_crew}
- Yesterday's Work: {yesterday_work}

USER INPUT: {voice_transcription_or_notes}

TASK: Generate a structured daily report including:
1. Weather conditions
2. Crew on site (names, hours)
3. Work performed (clear, professional language)
4. Materials received
5. Equipment used
6. Visitors
7. Delays or issues
8. Notes for tomorrow

Keep language professional and factual.
```

---

**END OF SPECIFICATION**

*This document is ready for Claude Code implementation.*
*Version 1.0 - December 2025*
*Prepared for: Lefebvre Design Solutions / Roofio*
