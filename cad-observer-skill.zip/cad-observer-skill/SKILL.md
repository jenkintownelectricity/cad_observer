---
name: cad-observer
description: CAD workflow observation and learning system. Use when user shares CAD screenshots, screen recordings, or asks Claude to analyze their drafting/design patterns. Logs observations systematically to build a persistent profile of user's CAD style, tool preferences, layer conventions, and decision-making patterns. Triggers on phrases like "watch my CAD", "analyze my drawing", "learn my style", "what patterns do you see", or when CAD screenshots are shared.
---

# CAD Observer Skill

Systematic observation and logging of CAD workflows to learn user patterns.

## CRITICAL: Question-First Protocol

**NEVER assume or guess what the user is doing. ASK FIRST.**

When observing CAD work, Claude MUST ask clarifying questions before logging observations. Wrong documentation is worse than no documentation.

### Required Questions (ask 2-3 per capture):

**Intent Questions:**
- "What are you trying to accomplish with this detail?"
- "Is this a standard detail or a custom solution?"
- "What drove this decision - spec requirement, field condition, or preference?"

**Context Questions:**
- "What specification section is this addressing?"
- "Is this based on a manufacturer detail or your own?"
- "What problem are you solving here?"

**Style Questions:**
- "Is this your preferred approach, or situational?"
- "Would you do this differently on another project?"
- "What would you name this pattern/technique?"

### Question Flow:
1. User shares screenshot/capture
2. Claude describes what it OBSERVES (not interprets)
3. Claude asks 2-3 targeted questions
4. User responds
5. THEN Claude logs the observation with user's actual intent

## Observation Protocol

When user shares CAD content (screenshots, recordings, command logs), extract and log:

### 1. Tool & Command Patterns
- Commands used (LINE, PLINE, OFFSET, TRIM, etc.)
- Command sequences (what follows what)
- Keyboard shortcuts vs toolbar clicks
- Frequency of specific tools

### 2. Layer Conventions
- Layer naming patterns
- Color/linetype assignments
- Layer organization logic
- What goes on which layer

### 3. Drawing Organization
- Viewport setup preferences
- Scale conventions
- Block naming patterns
- Xref management style

### 4. Decision Patterns
- How user starts a drawing
- Reference point preferences
- Dimension placement style
- Annotation conventions
- Error correction patterns

### 5. Style Signatures
- Line weight preferences
- Text height/style choices
- Hatch patterns commonly used
- Detail level preferences

## Logging Format

Always log observations as structured JSON. Include user's answers to questions:

```json
{
  "timestamp": "ISO-8601",
  "session_type": "screenshot|recording|command_log",
  "project_context": "description of what user is working on",
  "capture_metadata": {
    "click_x": 0,
    "click_y": 0,
    "mode": "cad|research"
  },
  "claude_observations": {
    "what_i_see": "factual description only",
    "commands_detected": [],
    "layer_patterns": [],
    "geometry_notes": []
  },
  "questions_asked": [
    {"question": "...", "user_response": "..."}
  ],
  "confirmed_intent": "user's stated purpose",
  "user_style_notes": "what user said about their approach",
  "predictions": [],
  "confidence": 0.0-1.0
}
```

## Capture Scripts

### Click Capture (CAD Work)
Captures on every mouse click with XY coordinates:
```bash
python scripts/click_capture.py --project "Project Name"
```
- Left/Right Click → Capture with coordinates
- Ctrl+Shift+R → Toggle Research mode
- Ctrl+Shift+Q → Stop

### Research Capture (Literature/Specs)
For capturing what you're reading:
```bash
python scripts/research_capture.py --project "Project Name"
```
- Ctrl+Shift+C → Capture screen
- Ctrl+Shift+S → Capture + tag source type
- Ctrl+Shift+T → Add annotation
- Ctrl+Shift+Q → Stop

## Storage Instructions

Persist observations locally or to Supabase:

```bash
# Local storage (default)
python scripts/log_observation.py --data '{...}'

# Supabase (cross-device sync)
python scripts/log_observation.py --supabase --data '{...}'

# View stats
python scripts/log_observation.py --stats
```

Storage locations:
- CAD captures: `~/.cad-observer/sessions/`
- Research captures: `~/.cad-observer/research/`
- Observation log: `~/.cad-observer/observations.jsonl`

## Analysis Protocol

When user asks "what have you learned about my style":
1. Load all past observations from storage
2. **Only reference observations with confirmed user intent**
3. Synthesize patterns across sessions
4. Present insights with confidence levels
5. Distinguish between "observed" vs "user-confirmed" patterns

## Prediction Protocol

After 5+ logged sessions WITH user confirmation, begin making predictions:
- "Based on what you've told me, you typically..."
- "You mentioned preferring X approach for this situation..."
- "Your stated convention is to..."

**Never predict based on unconfirmed observations.**

Track prediction accuracy by asking: "Did I get that right?"

## Integration with CAD APIs

### AutoCAD LISP Plugin (Recommended)

Install `scripts/cad-observer.lsp` for rich command-level logging:

1. Copy `cad-observer.lsp` to AutoCAD support path
2. Add to `acaddoc.lsp`: `(load "cad-observer.lsp")`
3. Or load manually: `APPLOAD` > select file

**AutoCAD Commands:**
```
CAD-OBSERVER-START   - Start logging session
CAD-OBSERVER-STOP    - Stop logging session
CAD-OBSERVER-STATUS  - Show current status
CAD-OBSERVER-TASK    - Check for Claude tasks
CAD-OBSERVER-AUTO    - Toggle auto-task execution
```

**What Gets Logged:**
- Every command with timestamp
- Command start/end/cancel events
- Cursor XY coordinates at command start
- Current layer at each action
- Object count changes
- Layer changes
- LISP function calls

### Sending Tasks TO AutoCAD

Claude can send commands to AutoCAD using the task system:

```bash
# Send AutoCAD commands
python scripts/cad_task.py script "ZOOM E" "LAYER M FLASH" "PLINE"

# Send LISP code
python scripts/cad_task.py lisp "(command \"CIRCLE\" \"0,0\" 5)"

# Query drawing state
python scripts/cad_task.py query

# Read command logs
python scripts/cad_task.py read-logs --analyze
```

**Task Flow:**
1. Claude creates task file in `C:/CADObserver/tasks/`
2. AutoCAD LISP plugin detects and executes task
3. Task moves to `C:/CADObserver/done/`
4. Results logged to `C:/CADObserver/logs/`

### Example: Claude Assists with Drawing

User: "Create a 4" reglet detail at the parapet"

Claude should:
1. Ask clarifying questions first
2. After user confirms, send task:
```python
# Create layers
send_script_task(["-LAYER", "M", "REGLET-DETAIL", "C", "5", "REGLET-DETAIL", ""])

# Draw reglet profile (user confirms dimensions first)
send_script_task([
    "PLINE",
    "0,0",      # Start point
    "4,0",      # 4" horizontal
    "4,0.5",    # Up to reglet depth
    "0,0.5",    # Back
    "C"         # Close
])
```

For AutoCAD command logging details, see `references/autocad_api.md`
