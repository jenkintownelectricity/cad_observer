"""
Assembly Drawing Archive Tool - With Roof Page Filter
Pre-filters PDFs to only process roof-related pages (cost optimization)
"""
from flask import Flask, render_template, request, jsonify
import os
import json
import PyPDF2
import re
from parsers.text_cleaner import clean_rtf_text, deduplicate_list
from parsers.assembly_parser import parse_assembly_letter
from parsers.arch_drawing_parser import parse_architectural_drawing
from parsers.roof_page_filter import filter_roof_pages, get_roof_page_numbers

app = Flask(__name__)
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def extract_text_from_pdf(filepath):
    """Extract text from PDF file with better error handling"""
    text = ""
    try:
        with open(filepath, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            total_pages = len(pdf_reader.pages)
            print(f"📄 Extracting {total_pages} pages from: {os.path.basename(filepath)}")

            for i, page in enumerate(pdf_reader.pages, 1):
                page_text = page.extract_text()
                text += page_text + "\n"
                print(f"  ✓ Page {i}/{total_pages} - {len(page_text)} chars")

            print(f"  📊 Total extracted: {len(text)} characters")
    except Exception as e:
        print(f"❌ Error extracting text from {filepath}: {str(e)}")
        return ""
    return text


def extract_text_from_pdf_filtered(filepath, page_numbers=None):
    """
    Extract text from specific pages only (for cost optimization).

    Args:
        filepath: Path to PDF
        page_numbers: List of 1-indexed page numbers to extract, or None for all

    Returns:
        Extracted text with page markers
    """
    text = ""
    try:
        with open(filepath, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            total_pages = len(pdf_reader.pages)

            if page_numbers is None:
                pages_to_extract = range(total_pages)
                print(f"📄 Extracting ALL {total_pages} pages from: {os.path.basename(filepath)}")
            else:
                # Convert to 0-indexed and validate
                pages_to_extract = [p - 1 for p in page_numbers if 0 < p <= total_pages]
                print(f"📄 Extracting {len(pages_to_extract)}/{total_pages} ROOF pages from: {os.path.basename(filepath)}")

            for i in pages_to_extract:
                page_text = pdf_reader.pages[i].extract_text() or ""
                text += f"\n--- PAGE {i+1} ---\n" + page_text + "\n"
                print(f"  ✓ Page {i+1} - {len(page_text)} chars")

            print(f"  📊 Total extracted: {len(text)} characters")
    except Exception as e:
        print(f"❌ Error extracting text from {filepath}: {str(e)}")
        return ""
    return text


def safe_jsonify(data):
    """Safely convert data to JSON-serializable format"""
    if isinstance(data, dict):
        return {k: safe_jsonify(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [safe_jsonify(item) for item in data]
    elif isinstance(data, (str, int, float, bool, type(None))):
        return data
    else:
        return str(data)

# ============================================================================
# DOCUMENT PARSERS
# ============================================================================

def parse_scope_of_work(text):
    """Parse Scope of Work document"""
    print("\n" + "="*60)
    print("🔍 PARSING SCOPE OF WORK")
    print("="*60)

    text = clean_rtf_text(text)

    materials = []
    material_patterns = [
        r'(?i)materials?:\s*([^\n]+)',
        r'(?i)product[s]?:\s*([^\n]+)',
    ]

    for pattern in material_patterns:
        matches = re.findall(pattern, text)
        materials.extend(matches)

    materials = deduplicate_list(materials)
    print(f"  ✓ Found {len(materials)} materials")

    requirements = []
    req_patterns = [
        r'(?i)requirement[s]?:\s*([^\n]+)',
        r'(?i)shall\s+([^\n]+)',
    ]

    for pattern in req_patterns:
        matches = re.findall(pattern, text)
        requirements.extend(matches)

    requirements = deduplicate_list(requirements[:10])
    print(f"  ✓ Found {len(requirements)} requirements")

    sentences = text.split('.')[:3]
    summary = '. '.join(sentences).strip()
    print(f"  ✓ Generated summary ({len(summary)} chars)")

    result = {
        'summary': summary[:500] if summary else None,
        'materials': materials[:15] if materials else None,
        'requirements': requirements if requirements else None
    }

    print("="*60 + "\n")
    return result


def parse_specification(text):
    """Parse Specification document"""
    print("\n" + "="*60)
    print("🔍 PARSING SPECIFICATION")
    print("="*60)

    manufacturers = []
    mfr_patterns = [
        r'(?i)manufacturer[s]?:\s*([^\n]+)',
        r'(?i)(?:Carlisle|GAF|Firestone|Johns Manville|Versico|Siplast|SOPREMA|Sika|Barrett|Tremco)',
    ]

    for pattern in mfr_patterns:
        matches = re.findall(pattern, text)
        manufacturers.extend(matches)

    manufacturers = deduplicate_list(manufacturers)
    print(f"  ✓ Found {len(manufacturers)} manufacturers")

    products = []
    product_patterns = [
        r'(?i)product[s]?:\s*([^\n]+)',
        r'(?i)[A-Z][a-z]+\s+\d+\s*mil',
    ]

    for pattern in product_patterns:
        matches = re.findall(pattern, text)
        products.extend(matches)

    products = deduplicate_list(products)
    print(f"  ✓ Found {len(products)} products")

    result = {
        'manufacturers': manufacturers[:10] if manufacturers else None,
        'products': products[:15] if products else None
    }

    print("="*60 + "\n")
    return result


def parse_drawing_file(text, filename, filepath=None):
    """
    Parse a single architectural drawing file.

    If filepath is provided, pre-filters to only process roof-related pages.
    This saves cost when sending to AI vision APIs.
    """
    print("\n" + "="*60)
    print(f"🏗️  PARSING ARCHITECTURAL DRAWING: {filename}")
    print("="*60)

    filter_result = None

    # Pre-filter for roof pages if filepath provided
    if filepath and os.path.exists(filepath):
        print("\n  🔍 PRE-FILTERING FOR ROOF CONTENT...")
        filter_result = filter_roof_pages(filepath, threshold=10, verbose=True)

        if filter_result['pages_to_process'] == 0:
            print("  ⚠️  No roof-related pages found in document")
            return {
                'filename': filename,
                'drawing_type': 'No Roof Content Detected',
                'roof_pages': [],
                'filtered_out': True,
                'total_pages': filter_result['total_pages'],
                'message': 'Document scanned but no roof/waterproofing content found'
            }

        # Re-extract only roof pages
        roof_page_nums = [p['page_num'] for p in filter_result['roof_pages']]
        text = extract_text_from_pdf_filtered(filepath, roof_page_nums)

        print(f"\n  💰 COST OPTIMIZATION:")
        print(f"     Total pages: {filter_result['total_pages']}")
        print(f"     Roof pages: {filter_result['pages_to_process']}")
        print(f"     Savings: {filter_result['savings_percent']}%")

    try:
        # Use the enhanced parser
        parsed = parse_architectural_drawing(text)

        # Add metadata
        parsed['filename'] = filename

        if filter_result:
            parsed['filter_stats'] = {
                'total_pages': filter_result['total_pages'],
                'roof_pages': filter_result['pages_to_process'],
                'savings_percent': filter_result['savings_percent'],
                'roof_page_numbers': [p['page_num'] for p in filter_result['roof_pages']]
            }

        # Print summary
        if 'roof_plans' in parsed and parsed['roof_plans']:
            print(f"\n  📊 EXTRACTION SUMMARY:")
            for i, plan in enumerate(parsed['roof_plans'], 1):
                print(f"\n  Roof Plan {i}:")
                print(f"    Sheet: {plan.get('detail_number', 'Unknown')}")
                print(f"    Type: {plan.get('type', 'Unknown')}")
                print(f"    Drains: {plan.get('drains', 'N/A')}")
                print(f"    Scuppers: {plan.get('scuppers', 'N/A')}")
                print(f"    RTUs/Curbs: {plan.get('rtus_curbs', 'N/A')}")
                print(f"    Penetrations: {plan.get('penetrations', 'N/A')}")
                print(f"    Square Footage: {plan.get('square_footage', 'N/A')}")
                print(f"    Scale: {plan.get('scale', 'N/A')}")
        else:
            print("  ⚠️  No roof plans detected in extracted text")

        print("\n" + "="*60 + "\n")
        return parsed

    except Exception as e:
        print(f"  ❌ ERROR parsing drawing: {str(e)}")
        import traceback
        traceback.print_exc()
        print("="*60 + "\n")
        return {
            'error': str(e),
            'filename': filename,
            'drawing_type': 'Error',
            'roof_pages': []
        }

# ============================================================================
# ROUTES
# ============================================================================

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')


@app.route('/parse', methods=['POST'])
def parse_files():
    """Main parsing endpoint - handles all document types"""
    print("\n" + "🚀 " + "="*58)
    print("🚀  NEW PARSING REQUEST RECEIVED")
    print("🚀 " + "="*58 + "\n")

    results = {
        'scope': None,
        'spec': None,
        'drawing': None,
        'assembly': None
    }

    # Process each category
    for category in ['scope', 'spec', 'drawing', 'assembly']:
        if category not in request.files:
            continue

        files = request.files.getlist(category)
        if not files or not files[0].filename:
            continue

        print(f"\n📂 Processing {len(files)} file(s) for category: {category.upper()}")
        print("-" * 60)

        # Handle multiple files for drawings and assemblies
        if category in ['drawing', 'assembly'] and len(files) > 1:
            results[category] = []

            for file in files:
                if file and file.filename:
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                    file.save(filepath)
                    print(f"\n  📥 Saved: {file.filename}")

                    if category == 'drawing':
                        # Use filtered extraction for drawings
                        parsed = parse_drawing_file("", file.filename, filepath=filepath)
                        results[category].append(parsed)
                    elif category == 'assembly':
                        text = extract_text_from_pdf(filepath)
                        parsed = parse_assembly_letter(text)
                        parsed['filename'] = file.filename
                        results[category].append(parsed)

        # Handle single file
        else:
            file = files[0]
            if file and file.filename:
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                file.save(filepath)
                print(f"\n  📥 Saved: {file.filename}")

                if category == 'scope':
                    text = extract_text_from_pdf(filepath)
                    results['scope'] = parse_scope_of_work(text)

                elif category == 'spec':
                    text = extract_text_from_pdf(filepath)
                    results['spec'] = parse_specification(text)

                elif category == 'drawing':
                    # Use filtered extraction for drawings
                    results['drawing'] = parse_drawing_file("", file.filename, filepath=filepath)

                elif category == 'assembly':
                    text = extract_text_from_pdf(filepath)
                    parsed = parse_assembly_letter(text)
                    parsed['filename'] = file.filename
                    results['assembly'] = parsed

    print("\n" + "✅ " + "="*58)
    print("✅  PARSING COMPLETE - SENDING RESULTS")
    print("✅ " + "="*58 + "\n")

    # Debug: Print result structure
    print("📤 RESULTS STRUCTURE:")
    for key, value in results.items():
        if value:
            if isinstance(value, list):
                print(f"  {key}: [{len(value)} items]")
            elif isinstance(value, dict):
                if 'filter_stats' in value:
                    stats = value['filter_stats']
                    print(f"  {key}: {{...}} (filtered {stats['roof_pages']}/{stats['total_pages']} pages)")
                else:
                    print(f"  {key}: {{...}}")
        else:
            print(f"  {key}: None")
    print()

    safe_results = safe_jsonify(results)
    return jsonify(safe_results)


@app.route('/filter-preview', methods=['POST'])
def filter_preview():
    """
    Preview which pages would be filtered before full processing.
    Useful for debugging and showing user what will be analyzed.
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if not file.filename:
        return jsonify({'error': 'No file selected'}), 400

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    result = filter_roof_pages(filepath, threshold=10, verbose=True)

    return jsonify({
        'filename': file.filename,
        'total_pages': result['total_pages'],
        'roof_pages_count': result['pages_to_process'],
        'savings_percent': result['savings_percent'],
        'roof_pages': [
            {
                'page': p['page_num'],
                'score': p['score'],
                'sheet': p['sheet_number'],
                'title': p['sheet_title']
            }
            for p in result['roof_pages']
        ]
    })


# ============================================================================
# RUN APP
# ============================================================================

if __name__ == '__main__':
    print("\n" + "🏗️ " + "="*58)
    print("🏗️  ASSEMBLY DRAWING ARCHIVE TOOL - WITH ROOF FILTER")
    print("🏗️  Flask server starting...")
    print("🏗️ " + "="*58 + "\n")
    app.run(debug=True, port=5000)
